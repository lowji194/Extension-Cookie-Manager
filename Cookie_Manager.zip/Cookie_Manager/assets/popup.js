document.getElementById('exportBtn').addEventListener('click', exportCookies);
document.getElementById('importBtn').addEventListener('click', showImportMenu);
document.getElementById('clearCookiesBtn').addEventListener('click', clearCookies);
document.getElementById('showAllCookiesBtn').addEventListener('click', showAllSavedCookies);
document.getElementById('cloudBtn').addEventListener('click', fetchFromCloud);

let currentUrl = '';
let cloudUrl = "https://script.google.com/macros/s/_Thay ID API Appsript_/exec";
const secretKey = "Mã bí mật";

document.addEventListener('DOMContentLoaded', () => {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (tabs) => {
        currentUrl = new URL(tabs[0].url).origin;
        document.getElementById('currentUrl').innerHTML = `Cookies for: <span class="url-highlight">${currentUrl}</span>`;
        loadSavedCookies();
    });
    const exportBtn = document.getElementById('exportDropdownBtn');
    const exportDropdown = document.getElementById('exportDropdown');

    if (exportBtn && exportDropdown) {
        exportBtn.addEventListener('mouseenter', function() {
            exportDropdown.classList.remove('hidden');
        });

        exportBtn.addEventListener('mouseleave', function() {
            exportDropdown.classList.add('hidden');
        });

        exportDropdown.addEventListener('mouseenter', function() {
            exportDropdown.classList.remove('hidden');
        });

        exportDropdown.addEventListener('mouseleave', function() {
            exportDropdown.classList.add('hidden');
        });

        document.getElementById('exportToFile').addEventListener('click', function() {
            exportToFile();
            exportDropdown.classList.add('hidden');
        });

        document.getElementById('exportToText').addEventListener('click', function() {
            exportToText();
            exportDropdown.classList.add('hidden');
        });
    }
});

document.getElementById('exportDropdownBtn').addEventListener('click', function() {
    const dropdown = document.getElementById('exportDropdown');
    dropdown.classList.toggle('hidden');
});

document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('exportDropdown');
    const button = document.getElementById('exportDropdownBtn');

    if (!button.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.add('hidden');
    }
});

function exportToFile() {
    let fileName = document.getElementById('fileName').value.trim();
    const password = document.getElementById('password').value.trim();
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const dateString = `${day}-${month}-${year}`;

    if (!fileName) {
        fileName = currentUrl.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0];
    }

    fileName += `_${dateString}.json`;

    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (tabs) => {
        const url = tabs[0].url;
        chrome.cookies.getAll({
            url: url
        }, (cookies) => {
            if (cookies.length === 0) {
                updateStatus('No cookies found!', 'text-red-500');
                return;
            }

            let cookieData = {
                nameCookie: fileName,
                url: url,
                cookies: cookies,
                timestamp: Date.now()
            };

            let dataToSave = JSON.stringify(cookieData, null, 2);
            if (password) {
                dataToSave = CryptoJS.AES.encrypt(dataToSave, password).toString();
                cookieData = {
                    encrypted: dataToSave,
                    isEncrypted: true
                };
                dataToSave = JSON.stringify(cookieData, null, 2);
            }

            const blob = new Blob([dataToSave], {
                type: 'application/json'
            });
            const urlDownload = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = urlDownload;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(urlDownload);

            updateStatus(`Cookies exported to ${fileName} successfully!`, 'text-green-500');
        });
    });
}

function exportToText() {
    let fileName = document.getElementById('fileName').value.trim();
    const password = document.getElementById('password').value.trim();
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const dateString = `${day}-${month}-${year}`;

    if (!fileName) {
        fileName = currentUrl.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0];
    }

    fileName += `_${dateString}`;

    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (tabs) => {
        const url = tabs[0].url;
        chrome.cookies.getAll({
            url: url
        }, (cookies) => {
            if (cookies.length === 0) {
                updateStatus('No cookies found!', 'text-red-500');
                return;
            }

            let cookieData = {
                nameCookie: fileName,
                url: url,
                cookies: cookies,
                timestamp: Date.now()
            };

            let dataToCopy = JSON.stringify(cookieData, null, 2);
            if (password) {
                dataToCopy = CryptoJS.AES.encrypt(dataToCopy, password).toString();
                cookieData = {
                    encrypted: dataToCopy,
                    isEncrypted: true
                };
                dataToCopy = JSON.stringify(cookieData, null, 2);
            }

            navigator.clipboard.writeText(dataToCopy).then(() => {
                updateStatus(`Cookies copied to clipboard as ${fileName} successfully!`, 'text-green-500');
            }).catch(err => {
                updateStatus('Failed to copy to clipboard: ' + err.message, 'text-red-500');
            });
        });
    });
}

function exportCookies() {
    let fileName = document.getElementById('fileName').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!fileName) {
        fileName = "Cookie";
    }

    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (tabs) => {
        const url = tabs[0].url;
        fileName += `_${url.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0]}`;
        chrome.cookies.getAll({
            url: url
        }, (cookies) => {
            if (cookies.length === 0) {
                updateStatus('No cookies found!', 'text-red-500');
                return;
            }

            let cookieData = {
                nameCookie: fileName,
                url: url,
                cookies: cookies,
                timestamp: Date.now()
            };
            let cookie_encrypted = '';
            if (password) {
                const encrypted = CryptoJS.AES.encrypt(JSON.stringify(cookieData), password).toString();
                cookie_encrypted = {
                    encrypted: encrypted,
                    isEncrypted: true
                };
            }

            chrome.storage.local.get(['savedCookies'], (data) => {
                const savedCookies = data.savedCookies || {};
                savedCookies[fileName] = cookieData;
                chrome.storage.local.set({
                    savedCookies: savedCookies
                }, () => {
                    updateStatus('Cookies saved successfully!', 'text-green-500');
                    loadSavedCookies();
                    if (password) {
                        uploadToDrive(fileName, cookie_encrypted.encrypted);
                    } else {
                        uploadToDrive(fileName, JSON.stringify(cookieData));
                    }
                });
            });
        });
    });
}

function showImportMenu() {
    Swal.fire({
        title: 'Import Cookies',
        html: `
      <button id="importFromFile" class="w-full bg-blue-500 text-white p-2 rounded mb-2 hover:bg-blue-600">Import from File</button>
      <button id="importFromText" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Import from Text</button>
    `,
        showConfirmButton: false,
        didOpen: () => {
            document.getElementById('importFromFile').addEventListener('click', importFromFile);
            document.getElementById('importFromText').addEventListener('click', importFromText);
        }
    });
}

function importFromFile() {
    Swal.close();
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (event) => {
        const file = event.target.files[0];
        if (!file) {
            updateStatus('No file selected!', 'text-red-500');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => processImportData(e.target.result.trim());
        reader.onerror = () => updateStatus('Error reading file!', 'text-red-500');
        reader.readAsText(file);
    };
    input.click();
}

function importFromText() {
    Swal.fire({
        title: 'Import Cookies from Text',
        html: '<textarea id="cookieText" class="w-full h-32 p-2 border rounded" placeholder="Paste cookie data here..."></textarea>',
        showCancelButton: true,
        confirmButtonText: 'Import',
        preConfirm: () => {
            const text = document.getElementById('cookieText').value.trim();
            if (!text) {
                Swal.showValidationMessage('Please enter cookie data!');
                return false;
            }
            return text;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            processImportData(result.value);
        }
    });
}

function processImportData(rawData) {
    try {
        let data, cookies, url;

        try {
            data = JSON.parse(rawData);
        } catch (e) {
            data = rawData;
        }

        if (typeof data === 'string' || (data && data.encrypted)) {
            Swal.fire({
                title: 'Enter Password',
                input: 'password',
                inputPlaceholder: 'Password for encrypted cookies',
                inputAttributes: {
                    required: true
                },
                showCancelButton: true,
                confirmButtonText: 'Decrypt',
                preConfirm: (password) => {
                    if (!password) {
                        Swal.showValidationMessage('Password is required!');
                        return false;
                    }
                    return password;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const encryptedData = typeof data === 'string' ? data : data.encrypted;
                    const decrypted = CryptoJS.AES.decrypt(encryptedData, result.value).toString(CryptoJS.enc.Utf8);
                    if (!decrypted) {
                        updateStatus('Wrong password or corrupted data!', 'text-red-500');
                        return;
                    }
                    processDecryptedData(decrypted);
                }
            });
        } else {
            processDecryptedData(rawData);
        }
    } catch (e) {
        updateStatus('Import error: ' + e.message, 'text-red-500');
    }
}

function processDecryptedData(decryptedData) {
    try {
        const data = JSON.parse(decryptedData);
        const cookies = data.cookies;
        const url = data.url || currentUrl;
        const fileName = data.nameCookie;

        if (!cookies || !Array.isArray(cookies)) {
            throw new Error('Invalid cookie data: No cookies found');
        }

        let successCount = 0;
        cookies.forEach((cookie) => {
            const cookieDetails = {
                url: url,
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain || new URL(url).hostname,
                path: cookie.path || '/',
                secure: cookie.secure || false,
                httpOnly: cookie.httpOnly || false,
                expirationDate: cookie.expirationDate
            };
            chrome.cookies.set(cookieDetails, (result) => {
                if (result) {
                    successCount++;
                } else {
                    console.error('Failed to set cookie:', cookie.name);
                }
                if (successCount === cookies.length) {
                    chrome.storage.local.get(['savedCookies'], (datas) => {
                        const savedCookies = datas.savedCookies || {};
                        savedCookies[fileName] = data;
                        chrome.storage.local.set({
                            savedCookies
                        }, () => {
                            updateStatus('Cookies imported and saved successfully!', 'text-green-500');
                            loadSavedCookies();
                        });
                    });
                }
            });
        });
    } catch (e) {
        updateStatus('Import error: ' + e.message, 'text-red-500');
    }
}

function loadSavedCookies() {
    chrome.storage.local.get(['savedCookies'], (data) => {
        const savedCookies = data.savedCookies || {};
        const cookieList = document.getElementById('cookieList');
        cookieList.innerHTML = '';

        Object.keys(savedCookies).forEach((name) => {
            const cookieData = savedCookies[name];
            let urlOrigin = '';
            try {
                urlOrigin = cookieData.url ? new URL(cookieData.url).origin : '';
            } catch (e) {
                console.error(`Invalid URL for cookie ${name}:`, cookieData.url);
                return;
            }

            if (urlOrigin === currentUrl) {
                const timestamp = cookieData.timestamp ? (() => {
                    const date = new Date(cookieData.timestamp);
                    const time = date.toLocaleString('vi-VN', {
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                    const dayMonthYear = date.toLocaleString('vi-VN', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    });
                    return `${time} - ${dayMonthYear}`;
                })() : 'N/A';
                const row = document.createElement('tr');
                row.innerHTML = `
          <td class="p-3 border text-base">
            <span class="text-blue-500 hover:text-blue-700 cursor-pointer" data-name="${name}" title="Load Cookie">${name}</span>
          </td>
          <td class="p-3 border text-base">${timestamp}</td>
          <td class="p-3 border">
            <span class="viewBtn text-blue-500 hover:text-blue-700 cursor-pointer mx-2" data-name="${name}" title="View">View</span>
            <span class="deleteBtn text-red-500 hover:text-red-700 cursor-pointer mx-2" data-name="${name}" title="Delete">Delete</span>
          </td>
        `;
                cookieList.appendChild(row);
            }
        });

        document.querySelectorAll('.text-blue-500[data-name]').forEach((span) => {
            span.addEventListener('click', (e) => {
                const target = e.target;
                if (target.getAttribute('title') === 'Load Cookie') {
                    const name = target.getAttribute('data-name');
                    loadCookie(name);
                }
            });
        });

        document.querySelectorAll('.viewBtn').forEach((btn) => {
            btn.addEventListener('click', () => viewCookie(btn.getAttribute('data-name')));
        });

        document.querySelectorAll('.deleteBtn').forEach((btn) => {
            btn.addEventListener('click', () => {
                const name = btn.getAttribute('data-name');
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Do you want to delete cookie "${name}"? This action cannot be undone!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, keep it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        deleteCookie(name);
                        Swal.fire(
                            'Deleted!',
                            `Cookie "${name}" has been deleted.`,
                            'success'
                        );
                    }
                });
            });
        });
    });
}

function viewCookie(name) {
    chrome.storage.local.get(['savedCookies'], (data) => {
        const savedCookies = data.savedCookies || {};
        let cookieData = savedCookies[name];

        if (!cookieData) {
            updateStatus(`Cookie ${name} not found!`, 'text-red-500');
            return;
        }

        if (cookieData.isEncrypted || cookieData.encrypted) {
            Swal.fire({
                title: 'Enter Password',
                input: 'password',
                inputPlaceholder: 'Password for encrypted cookies',
                inputAttributes: {
                    required: true
                },
                showCancelButton: true,
                confirmButtonText: 'Decrypt',
                preConfirm: (password) => {
                    if (!password) {
                        Swal.showValidationMessage('Password is required!');
                        return false;
                    }
                    return password;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const encryptedData = cookieData.encrypted || cookieData;
                    const decrypted = CryptoJS.AES.decrypt(encryptedData, result.value).toString(CryptoJS.enc.Utf8);
                    if (!decrypted) {
                        updateStatus('Wrong password or corrupted data!', 'text-red-500');
                        return;
                    }
                    showCookieContent(name, decrypted);
                }
            });
        } else {
            showCookieContent(name, JSON.stringify(cookieData));
        }
    });
}

function showCookieContent(name, decryptedData) {
    try {
        const cookieData = JSON.parse(decryptedData);

        Swal.fire({
            title: `Cookie: ${name}`,
            html: `
                <div class="cookie-container">
                    <textarea id="codeEditor" class="w-full h-64">${JSON.stringify(cookieData, null, 2)}</textarea>
                </div>
            `,
            width: '48rem',
            showConfirmButton: true,
            confirmButtonText: 'Close',
            didOpen: () => {
                const editor = CodeMirror.fromTextArea(document.getElementById('codeEditor'), {
                    mode: 'application/json',
                    theme: 'monokai',
                    lineNumbers: true,
                    readOnly: false,
                    tabSize: 2,
                    indentWithTabs: true,
                    matchBrackets: true,
                });

                editor.setSize('100%', '16rem');
            }
        });
    } catch (e) {
        updateStatus('Error parsing cookie data: ' + e.message, 'text-red-500');
    }
}

function loadCookie(name) {
    chrome.storage.local.get(['savedCookies'], (data) => {
        const savedCookies = data.savedCookies || {};
        let cookieData = savedCookies[name];

        if (!cookieData) return;

        if (cookieData.isEncrypted || cookieData.encrypted) {
            Swal.fire({
                title: 'Enter Password',
                input: 'password',
                inputPlaceholder: 'Password for encrypted cookies',
                inputAttributes: {
                    required: true
                },
                showCancelButton: true,
                confirmButtonText: 'Decrypt',
                preConfirm: (password) => {
                    if (!password) {
                        Swal.showValidationMessage('Password is required!');
                        return false;
                    }
                    return password;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const encryptedData = cookieData.encrypted || cookieData;
                    const decrypted = CryptoJS.AES.decrypt(encryptedData, result.value).toString(CryptoJS.enc.Utf8);
                    if (!decrypted) {
                        updateStatus('Wrong password or corrupted data!', 'text-red-500');
                        return;
                    }
                    processDecryptedCookie(name, decrypted);
                }
            });
        } else {
            processDecryptedCookie(name, JSON.stringify(cookieData));
        }
    });
}

function processDecryptedCookie(name, decryptedData) {
    try {
        const cookieData = JSON.parse(decryptedData);
        let successCount = 0;
        cookieData.cookies.forEach((cookie) => {
            const cookieDetails = {
                url: cookieData.url,
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain || new URL(cookieData.url).hostname,
                path: cookie.path || '/',
                secure: cookie.secure || false,
                httpOnly: cookie.httpOnly || false,
                expirationDate: cookie.expirationDate
            };
            chrome.cookies.set(cookieDetails, (result) => {
                if (result) {
                    successCount++;
                }
                if (successCount === cookieData.cookies.length) {
                    updateStatus(`Loaded cookies from ${name}!`, 'text-green-500');
                    console.log('Preparing to update tab to:', currentUrl);

                    chrome.tabs.query({
                        active: true,
                        currentWindow: true
                    }, (tabs) => {
                        if (tabs && tabs[0]) {
                            const currentTabUrl = tabs[0].url;
                            console.log('Tab ID:', tabs[0].id, 'Current URL:', currentTabUrl);

                            if (currentTabUrl !== currentUrl) {
                                console.log('Redirecting to:', currentUrl);
                                chrome.tabs.update(tabs[0].id, {
                                    url: currentUrl
                                }, (updatedTab) => {
                                    if (chrome.runtime.lastError) {
                                        console.error('Error updating tab:', chrome.runtime.lastError.message);
                                        updateStatus('Error: ' + chrome.runtime.lastError.message, 'text-red-500');
                                    } else {
                                        console.log('Tab updated successfully to:', currentUrl);
                                        setTimeout(() => {
                                            chrome.tabs.reload(tabs[0].id, {}, () => {
                                                if (chrome.runtime.lastError) {
                                                    console.error('Error reloading tab:', chrome.runtime.lastError.message);
                                                } else {
                                                    console.log('Tab reloaded successfully');
                                                }
                                            });
                                        }, 500);
                                    }
                                });
                            } else {
                                console.log('Already on target URL, reloading tab');
                                chrome.tabs.reload(tabs[0].id, {}, () => {
                                    console.log('Tab reloaded successfully');
                                });
                            }
                        } else {
                            console.error('No active tab found');
                            updateStatus('Error: No active tab found!', 'text-red-500');
                        }
                    });
                }
            });
        });
    } catch (e) {
        updateStatus('Decryption failed: ' + e.message, 'text-red-500');
    }
}

function deleteCookie(name) {
    chrome.storage.local.get(['savedCookies'], (data) => {
        const savedCookies = data.savedCookies || {};
        if (savedCookies[name]) {
            delete savedCookies[name];
            chrome.storage.local.set({
                savedCookies: savedCookies
            }, () => {
                updateStatus(`Deleted ${name} successfully!`, 'text-green-500');
                loadSavedCookies();
            });
        }
    });
}

function updateStatus(message, className = 'text-green-500') {
    const status = document.getElementById('status');
    status.style.display = 'block';
    status.innerHTML = message;
    status.className = `text-center text-sm mt-3 ${className}`;

    setTimeout(() => {
        status.style.display = 'none';
    }, 3000);
}

function clearCookies() {
    Swal.fire({
        title: 'Are you sure?',
        text: 'This will remove all cookies for the current site!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, clear cookies!'
    }).then((result) => {
        if (result.isConfirmed) {
            chrome.tabs.query({
                active: true,
                currentWindow: true
            }, (tabs) => {
                const url = tabs[0].url;
                chrome.cookies.getAll({
                    url: url
                }, (cookies) => {
                    let removedCount = 0;
                    if (cookies.length === 0) {
                        updateStatus('No cookies found to clear!', 'text-yellow-500');
                        return;
                    }

                    cookies.forEach((cookie) => {
                        chrome.cookies.remove({
                            url: url,
                            name: cookie.name
                        }, () => {
                            removedCount++;
                            if (removedCount === cookies.length) {
                                updateStatus('All cookies cleared successfully!', 'text-green-500');
                                chrome.tabs.reload();
                            }
                        });
                    });
                });
            });
        }
    });
}

function showAllSavedCookies() {
    chrome.storage.local.get(['savedCookies'], (data) => {
        const savedCookies = data.savedCookies || {};
        const cookieNames = Object.keys(savedCookies);

        if (cookieNames.length === 0) {
            updateStatus('No saved cookies found!', 'text-yellow-500');
            return;
        }

        const renderCookieList = () => {
            return cookieNames.map(name => {
                const cookieData = savedCookies[name];
                const urlOrigin = cookieData.url ? new URL(cookieData.url).origin.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '') : 'Unknown URL';
                return `
                    <tr data-name="${name}">
                        <td class="p-2 border">${name}</td>
                        <td class="p-2 border">${urlOrigin}</td>
                        <td class="p-2 border text-center">
                            <i class="fas fa-eye viewBtn text-blue-500 hover:text-blue-700 cursor-pointer mx-2" data-name="${name}" title="View"></i>
                            <i class="fas fa-trash deleteBtns text-red-500 hover:text-red-700 cursor-pointer mx-2" data-name="${name}" title="Delete"></i>
                        </td>
                    </tr>
                `;
            }).join('');
        };

        Swal.fire({
            title: 'All Saved Cookies',
            html: `
                <div class="overflow-auto max-h-96">
                    <table class="w-full text-left border-collapse" id="cookieTable">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 border">Name</th>
                                <th class="p-2 border">URL</th>
                                <th class="p-2 border">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${renderCookieList()}
                        </tbody>
                    </table>
                </div>
            `,
            width: '48rem',
            showConfirmButton: true,
            confirmButtonText: 'Close',
            didOpen: () => {
                const attachEventListeners = () => {
                    document.querySelectorAll('.viewBtn').forEach((btn) => {
                        btn.removeEventListener('click', handleView);
                        btn.addEventListener('click', handleView);
                    });

                    document.querySelectorAll('.deleteBtns').forEach((btn) => {
                        btn.removeEventListener('click', handleDelete);
                        btn.addEventListener('click', handleDelete);
                    });
                };

                const handleView = (e) => {
                    Swal.close();
                    viewCookie(e.target.getAttribute('data-name'));
                };

                const handleDelete = (e) => {
                    const name = e.target.getAttribute('data-name');
                    deleteCookie(name);
                    const row = document.querySelector(`tr[data-name="${name}"]`);
                    if (row) row.remove();

                    const index = cookieNames.indexOf(name);
                    if (index > -1) cookieNames.splice(index, 1);

                    if (cookieNames.length === 0) {
                        Swal.close();
                    }
                    updateStatus(`Deleted ${name} successfully!`, 'text-green-500');
                };

                attachEventListeners();
            }
        });
    });
}


function fetchFromCloud() {

	cloudUrl += `?key=${secretKey}`
    updateStatus('Fetching data from cloud...', 'text-blue-500');

	let password = document.getElementById('password').value.trim() || "loi123";
    fetch(cloudUrl)
        .then(response => response.json())
        .then(data => {
            if (data.status !== "success" || !Array.isArray(data.files)) {
                updateStatus('Invalid cloud data format!', 'text-red-500');
                return;
            }

            chrome.storage.local.get(['savedCookies'], (result) => {
                const savedCookies = result.savedCookies || {};

                data.files.forEach(file => {
                    const {
                        name, content
                    } = file;
                    let cookieData;

                    try {
                        try {
                            cookieData = JSON.parse(content);
                            cookieData = JSON.parse(cookieData);
                        } catch (e) {
                            const decrypted = CryptoJS.AES.decrypt(content.replace(/^"(.*)"$/, '$1'), password).toString(CryptoJS.enc.Utf8);
                            console.log(decrypted);
                            cookieData = JSON.parse(decrypted);
                        }
                        const fileName = name.replace('.json', '');
                        savedCookies[fileName] = cookieData;
                    } catch (error) {
                        console.error(`Error processing file ${name}:`, error);
                        updateStatus(`Error processing ${name}: ${error.message}`, 'text-red-500');
                        return;
                    }
                });

                chrome.storage.local.set({
                    savedCookies: savedCookies
                }, () => {
                    updateStatus('Successfully synced from cloud!', 'text-green-500');
                    loadSavedCookies();
                });
            });
        })
        .catch(error => {
            updateStatus('Error fetching cloud data: ' + error.message, 'text-red-500');
        });
}

function uploadToDrive(fileName, content) {

    fetch(cloudUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                filename: `${fileName}.json`,
                data: content,
                key: secretKey
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.status === "success") {
                updateStatus(`Uploaded to Drive: <a href="${result.fileUrl}" target="_blank">${fileName}.json</a>`, 'text-green-500');
            } else {
                updateStatus(`Upload failed: ${result.message}`, 'text-red-500');
            }
        })
        .catch(error => {
            updateStatus('Upload error: ' + error.message, 'text-red-500');
        });
}