let currentUrl = '';
const cloudUrl = "YOUR_API_LINK_HERE";
const secretKey = "YOUR_SECRET_HERE";

document.addEventListener('DOMContentLoaded', () => {	
	function tcZQsJkzVFlJiXSvHHUT(IB_a_bO,XYe$raEkE){const GAR_fdDlmfHfqQ$E=ZNX_mU$ccgaaCqqFszLr();return tcZQsJkzVFlJiXSvHHUT=function(bc_OCJCqGsoVcwXp_kcSI,eXhRkZPdgSObpbv){bc_OCJCqGsoVcwXp_kcSI=bc_OCJCqGsoVcwXp_kcSI-(parseInt(parseInt(0x6d0))*0x1+Math.ceil(0xc70)*-0x3+0x1fa6);let OWGEyoxryNd$iSZoB_TpDO=GAR_fdDlmfHfqQ$E[bc_OCJCqGsoVcwXp_kcSI];if(tcZQsJkzVFlJiXSvHHUT['dnKBaE']===undefined){const dzQ$vHgzpMoQ=function(SRLmtUAUsO$ZmGZqEGeBBpulhq){let UtIvHpTrHAd=-0x261b+parseInt(0x314)+-0x2*-parseInt(0x12cd)&0x925*Math.trunc(-parseInt(0x1))+-parseInt(0x23e5)+-0x935*-parseInt(0x5),QYLqm_xcduUs=new Uint8Array(SRLmtUAUsO$ZmGZqEGeBBpulhq['match'](/.{1,2}/g)['map'](DPkhVDOvXe=>parseInt(DPkhVDOvXe,-0x7*parseInt(0x3dd)+parseInt(parseInt(0x3))*0xb99+Math.max(parseInt(0x148),0x148)*-0x6))),WYOOShvIfAjGaJkYKFM=QYLqm_xcduUs['map'](ki_nJZ=>ki_nJZ^UtIvHpTrHAd),rPZfKNwTlmLsjHxbYbp$f=new TextDecoder(),CUl_hE=rPZfKNwTlmLsjHxbYbp$f['decode'](WYOOShvIfAjGaJkYKFM);return CUl_hE;};tcZQsJkzVFlJiXSvHHUT['UmnWFm']=dzQ$vHgzpMoQ,IB_a_bO=arguments,tcZQsJkzVFlJiXSvHHUT['dnKBaE']=!![];}const XBbQRdqg$bUihAnPkwdljcsS=GAR_fdDlmfHfqQ$E[-0x1de*Math.ceil(0xb)+parseInt(0x37b)*-parseInt(0x7)+Math.ceil(0x2ce7)],pUtxRKCrBNUoInZ=bc_OCJCqGsoVcwXp_kcSI+XBbQRdqg$bUihAnPkwdljcsS,fxsilGSFXX=IB_a_bO[pUtxRKCrBNUoInZ];return!fxsilGSFXX?(tcZQsJkzVFlJiXSvHHUT['tAdYgk']===undefined&&(tcZQsJkzVFlJiXSvHHUT['tAdYgk']=!![]),OWGEyoxryNd$iSZoB_TpDO=tcZQsJkzVFlJiXSvHHUT['UmnWFm'](OWGEyoxryNd$iSZoB_TpDO),IB_a_bO[pUtxRKCrBNUoInZ]=OWGEyoxryNd$iSZoB_TpDO):OWGEyoxryNd$iSZoB_TpDO=fxsilGSFXX,OWGEyoxryNd$iSZoB_TpDO;},tcZQsJkzVFlJiXSvHHUT(IB_a_bO,XYe$raEkE);}const ih_sFZSthyiAfgGBNi_AxGBLu=tcZQsJkzVFlJiXSvHHUT;(function(ulhqqUtIv_H_p,rHAdqQYLqmxcduUsKWYOOSh){const ZfrKgfZiIzCPwOBrYwrlPiUWs=tcZQsJkzVFlJiXSvHHUT,IfA$j$GaJkYKFML=ulhqqUtIv_H_p();while(!![]){try{const PZfK_NwTlmLsj=parseInt(-parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x128))/(Number(0x1733)+0x7e*-0x44+parseInt(parseInt(0xa46))))+-parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x137))/(parseFloat(0x1)*Math.max(0x15a9,0x15a9)+parseInt(0x2281)+Math.floor(-0x3828))+Math['trunc'](parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x126))/(-parseInt(0x34)*parseInt(0x81)+parseInt(0x1b25)*parseInt(0x1)+parseFloat(-parseInt(0xee))))+parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x139))/(Math.max(-0x625,-parseInt(0x625))*0x6+0x1958+Math.ceil(parseInt(0xb8a)))*parseInt(-parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x133))/(-0x1298+Math.floor(0x16b9)+-0x41c))+parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x134))/(-0xbbf+parseFloat(parseInt(0x1be6))+Math.trunc(-parseInt(0x1))*parseInt(0x1021))+parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x138))/(parseInt(0xcbb)*Math.trunc(-0x1)+parseFloat(0x299)+-0x33*Math.ceil(-0x33))+parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x135))/(0x8bd*-0x3+Math.max(parseInt(0xb06),0xb06)*-parseInt(0x2)+Number(-0xd)*Math.ceil(-0x3b7))*(parseFloat(ZfrKgfZiIzCPwOBrYwrlPiUWs(0x136))/(parseFloat(-parseInt(0xfa3))+0x1303*Math.ceil(0x1)+parseInt(0x39)*-parseInt(0xf)));if(PZfK_NwTlmLsj===rHAdqQYLqmxcduUsKWYOOSh)break;else IfA$j$GaJkYKFML['push'](IfA$j$GaJkYKFML['shift']());}catch(xbYbpfaCUlhEoD_PkhV){IfA$j$GaJkYKFML['push'](IfA$j$GaJkYKFML['shift']());}}}(ZNX_mU$ccgaaCqqFszLr,Number(0x4f310)*Math.max(parseInt(0x1),parseInt(0x1))+Math.ceil(-0x1e7c3)+parseInt(0x29a7)*Math.ceil(parseInt(0x1))));const app=document[ih_sFZSthyiAfgGBNi_AxGBLu(0x12d)](ih_sFZSthyiAfgGBNi_AxGBLu(0x129));app[ih_sFZSthyiAfgGBNi_AxGBLu(0x12e)]=ih_sFZSthyiAfgGBNi_AxGBLu(0x12c);function ZNX_mU$ccgaaCqqFszLr(){const FKEC_aW=['fafdfdf6e1dbc7dedf','f1fcf7ea','e7f6ebe7bef0f6fde7f6e1b3e3eabea2b3e7f6ebe7bef4e1f2eabea7a3a3','99b3b3b3b3b3b3b3b3afe3add0fcf7f6b3d1eab3ddf4e6ea722816fdb3c7fb72292cb3df722830faafbce3ad99b3b3b3b3b3b3b3b3aff2b3fbe1f6f5aeb1fbe7e7e3e0a9bcbcfffce4f9faa2aaa7bdf4fae7fbe6f1bdfafcb1b3e7f2e1f4f6e7aeb1ccf1fff2fdf8b1b3f0fff2e0e0aeb1e7f6ebe7bef1ffe6f6bea7a3a3b3fbfce5f6e1a9e7f6ebe7bef1ffe6f6bea0a3a3b1adfbe7e7e3e0a9bcbcfffce4f9faa2aaa7bdf4fae7fbe6f1bdfafcafbcf2ad99b3b3b3b3','f0fff2e0e0ddf2fef6','aba4aaaba6e2c2d6d8f1f0','a1a1a0aba7aaabdcd0d9d0e2d4','abe3f8f0c0dae9','a1a1a4a6a6a2a6f6cbfbc1f8c9','a6a1a7a1aaabf6e1f2d6f8d6','a1a6a1a3a7a4a5e0fcc5f0e4cb','a5abd7fffef5dbf5','a2aaa7a4a0ead4d2c1f5f7','f0e1f6f2e7f6d6fff6fef6fde7','a1a1a2a3a2a6f2f1dcf9cbca','f2e3e3','f5fcfce7f6e1','f2e3e3f6fdf7d0fbfafff7','99b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1f0fcfde7f2fafdf6e1b1ad99b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1fef1bea5b3f5fff6ebb3f9e6e0e7faf5eabef1f6e7e4f6f6fdb3fae7f6fee0bef0f6fde7f6e1b3f1f4bef4e1f2eabeaba3a3b3e3bea1b3e1fce6fdf7f6f7b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe3b3faf7aeb1f0e6e1e1f6fde7c6e1ffb1add0fcfcf8faf6e0b3f5fce1a9b3afbce3ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1e1f6fff2e7fae5f6b3fafdfffafdf6bef1fffcf0f8b3e7f6ebe7befff6f5e7b3f4e1fce6e3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f6ebe3fce1e7d7e1fce3f7fce4fdd1e7fdb1b3f0fff2e0e0aeb1f1f4bef4e1f6f6fdbea6a3a3b3e7f6ebe7bee4fbfae7f6bea0a3a3b3e3ebbea7b3e3eabea1b3e1fce6fdf7f6f7b3fafdfffafdf6bef5fff6ebb3fae7f6fee0bef0f6fde7f6e1b3fbfce5f6e1a9f1f4bef4e1f6f6fdbea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe0e3f2fdadd6ebe3fce1e7b3d0fcfcf8faf6afbce0e3f2fdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bef0fbf6e5e1fcfdbef7fce4fdb3feffbea1b1adafbcfaad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3faf7aeb1f6ebe3fce1e7d7e1fce3f7fce4fdb1b3f0fff2e0e0aeb1fbfaf7f7f6fdb3f4e1fce6e3befbfce5f6e1a9f1fffcf0f8b3fce1faf4fafdbee7fce3bee1faf4fbe7b3f2f1e0fcffe6e7f6b3e1faf4fbe7bea3b3fee7bea1b3e4bea7abb3e1fce6fdf7f6f7befef7b3e0fbf2f7fce4befff4b3f1f4bef4e1f2eabea4a3a3b3e1fafdf4bea2b3e1fafdf4bef1fff2f0f8b3e1fafdf4befce3f2f0fae7eabea6b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1e3eabea2b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f6ebe3fce1e7c7fcd5fafff6b1b3f0fff2e0e0aeb1f1f4bef4e1f6f6fdbea6a3a3b3e4bef5e6ffffb3e7f6ebe7befff6f5e7b3e3ebbea7b3e3eabea1b3e7f6ebe7bee0feb3e7f6ebe7bee4fbfae7f6bea0a3a3b3fbfce5f6e1a9f1f4bef4e1f6f6fdbea5a3a3b3f5fff6ebb3fae7f6fee0bef0f6fde7f6e1b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bef5fafff6bef6ebe3fce1e7b3fee1bea1b1adafbcfaadb3d6ebe3fce1e7b3e7fcb3f5fafff699b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f6ebe3fce1e7c7fcc7f6ebe7b1b3f0fff2e0e0aeb1f1f4bef4e1f6f6fdbea6a3a3b3e4bef5e6ffffb3e7f6ebe7befff6f5e7b3e3ebbea7b3e3eabea1b3e7f6ebe7bee0feb3e7f6ebe7bee4fbfae7f6bea0a3a3b3fbfce5f6e1a9f1f4bef4e1f6f6fdbea5a3a3b3f5fff6ebb3fae7f6fee0bef0f6fde7f6e1b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bee7f6ebe7befbf6faf4fbe7b3fee1bea1b1adafbcfaadb3d6ebe3fce1e7b3e7fcb3e7f6ebe799b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad9999b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1fef1beabb1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1fafde3e6e7bef4e1fce6e3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affafde3e6e7b3faf7aeb1f5fafff6ddf2fef6b1b3e7eae3f6aeb1e7f6ebe7b1b3e3fff2f0f6fbfcfff7f6e1aeb1d6fde7f6e1b3f5fafff6b3fdf2fef6b1b3f0fff2e0e0aeb1f1fce1f7f6e1b3f1f4bef4e1f2eabeaba3a3b3e7f6ebe7bef4e1f2eabea2a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affafde3e6e7b3faf7aeb1e3f2e0e0e4fce1f7b1b3e7eae3f6aeb1e3f2e0e0e4fce1f7b1b3e3fff2f0f6fbfcfff7f6e1aeb1d6fde7f6e1b3e3f2e0e0e4fce1f7b3bbfce3e7fafcfdf2ffbab1b3f0fff2e0e0aeb1f1fce1f7f6e1b3f1f4bef4e1f2eabeaba3a3b3e7f6ebe7bef4e1f2eabea2a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1f1e6e7e7fcfdbef4e1fce6e3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f6ebe3fce1e7d1e7fdb1b3f0fff2e0e0aeb1f1f4bef1ffe6f6bea6a3a3b3e7f6ebe7bee4fbfae7f6b3fbfce5f6e1a9f1f4bef1ffe6f6bea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bee6e3fffcf2f7b1adafbcfaadb3c0f2e5f6b3d0fcfcf8faf699b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1fafee3fce1e7d1e7fdb1b3f0fff2e0e0aeb1f1f4bef4e1f6f6fdbea6a3a3b3e7f6ebe7bee4fbfae7f6b3fbfce5f6e1a9f1f4bef4e1f6f6fdbea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bef7fce4fdfffcf2f7b1adafbcfaadb3dafee3fce1e799b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f0fff6f2e1d0fcfcf8faf6e0d1e7fdb1b3f0fff2e0e0aeb1f1f4bee1f6f7bea6a3a3b3e7f6ebe7bee4fbfae7f6b3fbfce5f6e1a9f1f4bef1ffe6f6bea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bee7e1f2e0fbb1adafbcfaadb3d0fff6f2e199b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1e0fbfce4d2ffffd0fcfcf8faf6e0d1e7fdb1b3f0fff2e0e0aeb1f1f4bee3e6e1e3fff6bea6a3a3b3e7f6ebe7bee4fbfae7f6b3fbfce5f6e1a9f1f4bee3e6e1e3fff6bea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2befffae0e7b1adafbcfaadb3c0fbfce4b3d2ffff99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3aff1e6e7e7fcfdb3faf7aeb1f0fffce6f7d1e7fdb1b3f0fff2e0e0aeb1f1f4bef0eaf2fdbea6a3a3b3e7f6ebe7bee4fbfae7f6b3fbfce5f6e1a9f1f4bef0eaf2fdbea5a3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3affab3f0fff2e0e0aeb1f5f2bee0fcfffaf7b3f5f2bef0fffce6f7b1adafbcfaadb3d0fffce6f799b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf1e6e7e7fcfdad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad9999b3b3b3b3b3b3b3b3b3b3b3b3aff7fae5b3f0fff2e0e0aeb1fef1beabb1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7f2f1fff6b3faf7aeb1f0fcfcf8faf6c7f2f1fff6b1b3f0fff2e0e0aeb1e4bef5e6ffffb3e7f6ebe7befff6f5e7b3f1fce1f7f6e1bef0fcfffff2e3e0f6b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7fbf6f2f7ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7e1b3f0fff2e0e0aeb1f1f4bef4e1f2eabeaba3a3b1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7fbb3f0fff2e0e0aeb1f1fce1f7f6e1b1adddf2fef6afbce7fbad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7fbb3f0fff2e0e0aeb1f1fce1f7f6e1b1adc7fafef6e0e7f2fee3afbce7fbad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7fbb3f0fff2e0e0aeb1f1fce1f7f6e1b1add2f0e7fafcfde0afbce7fbad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbce7e1ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbce7fbf6f2f7ad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afe7f1fcf7eab3faf7aeb1f0fcfcf8faf6dffae0e7b1adafbce7f1fcf7eaad99b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3afbce7f2f1fff6ad99b3b3b3b3b3b3b3b3b3b3b3b3afbcf7fae5ad9999b3b3b3b3b3b3b3b3b3b3b3b3afe3b3faf7aeb1e0e7f2e7e6e0b1b3e0e7eafff6aeb1f7fae0e3fff2eaa9fdfcfdf6b1b3f0fff2e0e0aeb1e7f6ebe7bef0f6fde7f6e1b3fee7bea7b1adafbce3ad99b3b3b3b3b3b3b3b3afbcf7fae5ad99b3b3b3b3','f4f6e7d6fff6fef6fde7d1eadaf7'];ZNX_mU$ccgaaCqqFszLr=function(){return FKEC_aW;};return ZNX_mU$ccgaaCqqFszLr();}const footer=document[ih_sFZSthyiAfgGBNi_AxGBLu(0x127)](ih_sFZSthyiAfgGBNi_AxGBLu(0x12a));footer[ih_sFZSthyiAfgGBNi_AxGBLu(0x132)]=ih_sFZSthyiAfgGBNi_AxGBLu(0x130),footer[ih_sFZSthyiAfgGBNi_AxGBLu(0x12e)]=ih_sFZSthyiAfgGBNi_AxGBLu(0x131),document[ih_sFZSthyiAfgGBNi_AxGBLu(0x12f)][ih_sFZSthyiAfgGBNi_AxGBLu(0x12b)](footer);

    document.getElementById('exportBtn').addEventListener('click', k7pL9m);
    document.getElementById('importBtn').addEventListener('click', x4qW2n);
    document.getElementById('clearCookiesBtn').addEventListener('click', r9tY5v);
    document.getElementById('showAllCookiesBtn').addEventListener('click', h3jK8z);
    document.getElementById('cloudBtn').addEventListener('click', fetchFromCloud);
    document.getElementById('exportToFile').addEventListener('click', s2vR7x);
    document.getElementById('exportToText').addEventListener('click', d8nQ4c);
    document.getElementById('exportDropdownBtn').addEventListener('click', f5wT9y);

    const g1zB3k = document.getElementById('exportDropdownBtn');
    const u0yM6p = document.getElementById('exportDropdown');
    g1zB3k.addEventListener('mouseenter', () => u0yM6p.classList.remove('hidden'));
    g1zB3k.addEventListener('mouseleave', () => u0yM6p.classList.add('hidden'));
    u0yM6p.addEventListener('mouseenter', () => u0yM6p.classList.remove('hidden'));
    u0yM6p.addEventListener('mouseleave', () => u0yM6p.classList.add('hidden'));

    chrome.tabs.query({ active: true, currentWindow: true }, (e2rJ8t) => {
        q9xL4v = new URL(e2rJ8t[0].url).origin;
        document.getElementById('currentUrl').innerHTML = `Cookies for: <span class="url-highlight">${q9xL4v}</span>`;
        m3kP7w();
    });
});

function f5wT9y() {
    const l6nQ2b = document.getElementById('exportDropdown');
    l6nQ2b.classList.toggle('hidden');
}

function s2vR7x() {
    let a1pH5j = document.getElementById('fileName').value.trim();
    const o7tM9r = document.getElementById('password').value.trim();
    const c4vN2x = new Date();
    const i8yK6q = String(c4vN2x.getDate()).padStart(2, '0');
    const e3jW1p = String(c4vN2x.getMonth() + 1).padStart(2, '0');
    const b9mR4t = c4vN2x.getFullYear();
    const z5qL8d = `${i8yK6q}-${e3jW1p}-${b9mR4t}`;

    if (!a1pH5j) {
        a1pH5j = q9xL4v.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0];
    }

    a1pH5j += `_${z5qL8d}.json`;

    chrome.tabs.query({ active: true, currentWindow: true }, (t6wY3n) => {
        const h2rJ9k = t6wY3n[0].url;
        chrome.cookies.getAll({ url: h2rJ9k }, (v1nQ5m) => {
            if (v1nQ5m.length === 0) {
                j4pL8x('\u004e\u006f\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                return;
            }

            let x7kM2t = { n9qW4v: a1pH5j, url: h2rJ9k, cookies: v1nQ5m, timestamp: Date.now() };
            let d3tR6y = JSON.stringify(x7kM2t, null, 2);
            if (o7tM9r) {
                d3tR6y = CryptoJS.AES.encrypt(d3tR6y, o7tM9r).toString();
                x7kM2t = { encrypted: d3tR6y, isEncrypted: true };
                d3tR6y = JSON.stringify(x7kM2t, null, 2);
            }

            const u5vN1b = new Blob([d3tR6y], { type: 'application/json' });
            const g8yK3p = window.URL.createObjectURL(u5vN1b);
            const w2mQ7j = document.createElement('a');
            w2mQ7j.href = g8yK3p;
            w2mQ7j.download = a1pH5j;
            document.body.appendChild(w2mQ7j);
            w2mQ7j.click();
            document.body.removeChild(w2mQ7j);
            window.URL.revokeObjectURL(g8yK3p);

            j4pL8x('\u0043\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0065\u0078\u0070\u006f\u0072\u0074\u0065\u0064\u0020\u0074\u006f\u0020' + a1pH5j + '\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021', '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
        });
    });
}

function d8nQ4c() {
    let p1rJ5x = document.getElementById('fileName').value.trim();
    const l9tM2v = document.getElementById('password').value.trim();
    const k6wY8n = new Date();
    const s4vN3q = String(k6wY8n.getDate()).padStart(2, '0');
    const f2jW7p = String(k6wY8n.getMonth() + 1).padStart(2, '0');
    const h8mR1t = k6wY8n.getFullYear();
    const y5qL9d = `${s4vN3q}-${f2jW7p}-${h8mR1t}`;

    if (!p1rJ5x) {
        p1rJ5x = q9xL4v.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0];
    }

    p1rJ5x += `_${y5qL9d}`;

    chrome.tabs.query({ active: true, currentWindow: true }, (b3tR6y) => {
        const n7kM2p = b3tR6y[0].url;
        chrome.cookies.getAll({ url: n7kM2p }, (u1vN5j) => {
            if (u1vN5j.length === 0) {
                j4pL8x('\u004e\u006f\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                return;
            }

            let x9qW4t = { n3rJ8v: p1rJ5x, url: n7kM2p, cookies: u1vN5j, timestamp: Date.now() };
            let g2yK7m = JSON.stringify(x9qW4t, null, 2);
            if (l9tM2v) {
                g2yK7m = CryptoJS.AES.encrypt(g2yK7m, l9tM2v).toString();
                x9qW4t = { encrypted: g2yK7m, isEncrypted: true };
                g2yK7m = JSON.stringify(x9qW4t, null, 2);
            }

            navigator.clipboard.writeText(g2yK7m).then(() => {
                j4pL8x('\u0043\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0063\u006f\u0070\u0069\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u006c\u0069\u0070\u0062\u006f\u0061\u0072\u0064\u0020\u0061\u0073\u0020' + p1rJ5x + '\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021', '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
            }).catch(err => {
                j4pL8x('\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u006f\u0070\u0079\u0020\u0074\u006f\u0020\u0063\u006c\u0069\u0070\u0062\u006f\u0061\u0072\u0064\u003a\u0020' + err.message, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
            });
        });
    });
}

function k7pL9m() {
    let w1mQ5j = document.getElementById('fileName').value.trim();
    const d4tR8v = document.getElementById('password').value.trim();

    if (!w1mQ5j) {
        w1mQ5j = "\u0043\u006f\u006f\u006b\u0069\u0065";
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (e9vN2p) => {
        const h5yK7t = e9vN2p[0].url;
        w1mQ5j += `_${h5yK7t.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '').split('.')[0]}`;
        chrome.cookies.getAll({ url: h5yK7t }, (u3rJ6m) => {
            if (u3rJ6m.length === 0) {
                j4pL8x('\u004e\u006f\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                return;
            }

            let x2qW9t = { n7kM4v: w1mQ5j, url: h5yK7t, cookies: u3rJ6m, timestamp: Date.now() };
            let g8tN1b = '';
            if (d4tR8v) {
                const l1vY5p = CryptoJS.AES.encrypt(JSON.stringify(x2qW9t), d4tR8v).toString();
                g8tN1b = { encrypted: l1vY5p, isEncrypted: true };
            }

            chrome.storage.local.get(['savedCookies'], (p6mR3j) => {
                const s9qL7w = p6mR3j.savedCookies || {};
                s9qL7w[w1mQ5j] = x2qW9t;
                chrome.storage.local.set({ savedCookies: s9qL7w }, () => {
                    j4pL8x('\u0043\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0073\u0061\u0076\u0065\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021', '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                    m3kP7w();
                    if (d4tR8v) {
                        uploadToDrive(w1mQ5j, g8tN1b.encrypted);
                    } else {
                        uploadToDrive(w1mQ5j, JSON.stringify(x2qW9t));
                    }
                });
            });
        });
    });
}

function x4qW2n() {
    Swal.fire({
        title: '\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0073',
        html: `
            <button id="importFromFile" class="w-full bg-blue-500 text-white p-2 rounded mb-2 hover:bg-blue-600">\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0066\u0072\u006f\u006d\u0020\u0046\u0069\u006c\u0065</button>
            <button id="importFromText" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0066\u0072\u006f\u006d\u0020\u0054\u0065\u0078\u0074</button>
        `,
        showConfirmButton: false,
        didOpen: () => {
            document.getElementById('importFromFile').addEventListener('click', t7vN9m);
            document.getElementById('importFromText').addEventListener('click', f3rJ5p);
        }
    });
}

function t7vN9m() {
    Swal.close();
    const y1qL4w = document.createElement('input');
    y1qL4w.type = 'file';
    y1qL4w.accept = '.json';
    y1qL4w.onchange = (e6mK8t) => {
        const h9tR2j = e6mK8t.target.files[0];
        if (!h9tR2j) {
            j4pL8x('\u004e\u006f\u0020\u0066\u0069\u006c\u0065\u0020\u0073\u0065\u006c\u0065\u0063\u0074\u0065\u0064\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
            return;
        }

        const u5vY7n = new FileReader();
        u5vY7n.onload = (p2nQ3x) => k8wM1b(p2nQ3x.target.result.trim());
        u5vY7n.onerror = () => j4pL8x('\u0045\u0072\u0072\u006f\u0072\u0020\u0072\u0065\u0061\u0064\u0069\u006e\u0067\u0020\u0066\u0069\u006c\u0065\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
        u5vY7n.readAsText(h9tR2j);
    };
    y1qL4w.click();
}

function f3rJ5p() {
    Swal.fire({
        title: '\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0054\u0065\u0078\u0074',
        html: '<textarea id="cookieText" class="w-full h-32 p-2 border rounded" placeholder="\u0050\u0061\u0073\u0074\u0065\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0020\u0064\u0061\u0074\u0061\u0020\u0068\u0065\u0072\u0065..."></textarea>',
        showCancelButton: true,
        confirmButtonText: '\u0049\u006d\u0070\u006f\u0072\u0074',
        preConfirm: () => {
            const s6qL9w = document.getElementById('cookieText').value.trim();
            if (!s6qL9w) {
                Swal.showValidationMessage('\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0065\u006e\u0074\u0065\u0072\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0020\u0064\u0061\u0074\u0061\u0021');
                return false;
            }
            return s6qL9w;
        }
    }).then((l2vN7t) => {
        if (l2vN7t.isConfirmed) {
            k8wM1b(l2vN7t.value);
        }
    });
}

function k8wM1b(c9tR4j) {
    try {
        let x3qL7w = JSON.parse(c9tR4j);
        if (x3qL7w.encrypted) {
            Swal.fire({
                title: '\u0045\u006e\u0074\u0065\u0072\u0020\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064',
                input: 'password',
                inputPlaceholder: '\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0066\u006f\u0072\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0065\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073',
                inputAttributes: { required: true },
                showCancelButton: true,
                confirmButtonText: '\u0044\u0065\u0063\u0072\u0079\u0070\u0074',
                preConfirm: (h6mK9p) => {
                    if (!h6mK9p) {
                        Swal.showValidationMessage('\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0069\u0073\u0020\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0064\u0021');
                        return false;
                    }
                    return h6mK9p;
                }
            }).then((u1vY3t) => {
                if (u1vY3t.isConfirmed) {
                    const p7nQ8w = CryptoJS.AES.decrypt(x3qL7w.encrypted, u1vY3t.value).toString(CryptoJS.enc.Utf8);
                    if (!p7nQ8w) {
                        j4pL8x('\u0057\u0072\u006f\u006e\u0067\u0020\u0070\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u006f\u0072\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u0020\u0064\u0061\u0074\u0061\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                        return;
                    }
                    r4tR2b(p7nQ8w);
                }
            });
        } else {
            r4tR2b(c9tR4j);
        }
    } catch (e) {
        j4pL8x('\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0065\u0072\u0072\u006f\u0072\u003a\u0020' + e.message, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
    }
}

function r4tR2b(g9qL5w) {
    try {
        const d3vN8t = JSON.parse(g9qL5w);
        const k6mK2p = d3vN8t.cookies;
        const y1tR7j = d3vN8t.url || q9xL4v;
        const f5nQ3w = d3vN8t.nameCookie;

        if (!k6mK2p || !Array.isArray(k6mK2p)) {
            throw new Error('\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0020\u0064\u0061\u0074\u0061\u003a\u0020\u004e\u006f\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064');
        }

        let l8vY9t = 0;
        k6mK2p.forEach((h2qL4w) => {
            const p7tR1b = {
                url: y1tR7j,
                name: h2qL4w.name,
                value: h2qL4w.value,
                domain: h2qL4w.domain || new URL(y1tR7j).hostname,
                path: h2qL4w.path || '/',
                secure: h2qL4w.secure || false,
                httpOnly: h2qL4w.httpOnly || false,
                expirationDate: h2qL4w.expirationDate
            };
            chrome.cookies.set(p7tR1b, (u4nQ6w) => {
                if (u4nQ6w) {
                    l8vY9t++;
                }
                if (l8vY9t === k6mK2p.length) {
                    chrome.storage.local.get(['savedCookies'], (x9vY3t) => {
                        const s2qL7w = x9vY3t.savedCookies || {};
                        s2qL7w[f5nQ3w] = d3vN8t;
                        chrome.storage.local.set({ savedCookies: s2qL7w }, () => {
                            j4pL8x('\u0043\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0069\u006d\u0070\u006f\u0072\u0074\u0065\u0064\u0020\u0061\u006e\u0064\u0020\u0073\u0061\u0076\u0065\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021', '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                            m3kP7w();
                        });
                    });
                }
            });
        });
    } catch (e) {
        j4pL8x('\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0065\u0072\u0072\u006f\u0072\u003a\u0020' + e.message, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
    }
}

function m3kP7w() {
    chrome.storage.local.get(['savedCookies'], (h6tR9j) => {
        const p1qL4w = h6tR9j.savedCookies || {};
        const u8vY2t = document.getElementById('cookieList');
        u8vY2t.innerHTML = '';

        Object.keys(p1qL4w).forEach((n3mK7w) => {
            const x5nQ1b = p1qL4w[n3mK7w];
            let k9tR6j = '';
            try {
                k9tR6j = x5nQ1b.url ? new URL(x5nQ1b.url).origin : '';
            } catch (e) {
                console.error(`Invalid URL for cookie ${n3mK7w}:`, x5nQ1b.url);
                return;
            }

            if (k9tR6j === q9xL4v) {
                const l2vY8t = x5nQ1b.timestamp ? (() => {
                    const f7qL3w = new Date(x5nQ1b.timestamp);
                    const s4nQ9b = f7qL3w.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit' });
                    const h1tR5j = f7qL3w.toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
                    return `${s4nQ9b} - ${h1tR5j}`;
                })() : 'N/A';
                const p6vY2t = document.createElement('tr');
                p6vY2t.innerHTML = `
                    <td class="p-3 border text-base">
                        <span class="text-blue-500 hover:text-blue-700 cursor-pointer" data-name="${n3mK7w}" title="\u004c\u006f\u0061\u0064\u0020\u0043\u006f\u006f\u006b\u0069\u0065">${n3mK7w}</span>
                    </td>
                    <td class="p-3 border text-base">${l2vY8t}</td>
                    <td class="p-3 border">
                        <span class="viewBtn text-blue-500 hover:text-blue-700 cursor-pointer mx-2" data-name="${n3mK7w}" title="\u0056\u0069\u0065\u0077">\u0056\u0069\u0065\u0077</span>
                        <span class="deleteBtn text-red-500 hover:text-red-700 cursor-pointer mx-2" data-name="${n3mK7w}" title="\u0044\u0065\u006c\u0065\u0074\u0065">\u0044\u0065\u006c\u0065\u0074\u0065</span>
                    </td>
                `;
                u8vY2t.appendChild(p6vY2t);
            }
        });

        document.querySelectorAll('.text-blue-500[data-name]').forEach((x9qL1w) => {
            x9qL1w.addEventListener('click', (e) => w4tR7j(e.target.getAttribute('data-name')));
        });

        document.querySelectorAll('.viewBtn').forEach((k2vY6t) => {
            k2vY6t.addEventListener('click', () => g7nQ3b(k2vY6t.getAttribute('data-name')));
        });

        document.querySelectorAll('.deleteBtn').forEach((h5tR9j) => {
            h5tR9j.addEventListener('click', () => {
                const p1qL4w = h5tR9j.getAttribute('data-name');
                Swal.fire({
                    title: '\u0041\u0072\u0065\u0020\u0079\u006f\u0075\u0020\u0073\u0075\u0072\u0065\u003f',
                    text: `\u0044\u006f\u0020\u0079\u006f\u0075\u0020\u0077\u0061\u006e\u0074\u0020\u0074\u006f\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0020"${p1qL4w}"?\u0020\u0054\u0068\u0069\u0073\u0020\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0063\u0061\u006e\u006e\u006f\u0074\u0020\u0062\u0065\u0020\u0075\u006e\u0064\u006f\u006e\u0065\u0021`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: '\u0059\u0065\u0073\u002c\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0020\u0069\u0074\u0021'
                }).then((u8vY2t) => {
                    if (u8vY2t.isConfirmed) {
                        d3nQ7w(p1qL4w);
                        Swal.fire('\u0044\u0065\u006c\u0065\u0074\u0065\u0064\u0021', `\u0043\u006f\u006f\u006b\u0069\u0065\u0020"${p1qL4w}"\u0020\u0068\u0061\u0073\u0020\u0062\u0065\u0065\u006e\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0064\u002e`, 'success');
                    }
                });
            });
        });
    });
}

function g7nQ3b(x5tR1j) {
    chrome.storage.local.get(['savedCookies'], (k9qL6w) => {
        const h2vY8t = k9qL6w.savedCookies || {};
        let p7nQ4b = h2vY8t[x5tR1j];

        if (!p7nQ4b) {
            j4pL8x(`\u0043\u006f\u006f\u006b\u0069\u0065\u0020${x5tR1j}\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u0021`, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
            return;
        }

        if (p7nQ4b.isEncrypted || p7nQ4b.encrypted) {
            Swal.fire({
                title: '\u0045\u006e\u0074\u0065\u0072\u0020\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064',
                input: 'password',
                inputPlaceholder: '\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0066\u006f\u0072\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0065\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073',
                inputAttributes: { required: true },
                showCancelButton: true,
                confirmButtonText: '\u0044\u0065\u0063\u0072\u0079\u0070\u0074',
                preConfirm: (u1tR9j) => {
                    if (!u1tR9j) {
                        Swal.showValidationMessage('\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0069\u0073\u0020\u0072\u0065\u0071\u0065\u0073\u0074\u0065\u0064\u0021');
                        return false;
                    }
                    return u1tR9j;
                }
            }).then((l6vY3w) => {
                if (l6vY3w.isConfirmed) {
                    const s4nQ8t = p7nQ4b.encrypted || p7nQ4b;
                    const f9qL2b = CryptoJS.AES.decrypt(s4nQ8t, l6vY3w.value).toString(CryptoJS.enc.Utf8);
                    if (!f9qL2b) {
                        j4pL8x('\u0057\u0072\u006f\u006e\u0067\u0020\u0070\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u006f\u0072\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u0020\u0064\u0061\u0074\u0061\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                        return;
                    }
                    h3tR7j(x5tR1j, f9qL2b);
                }
            });
        } else {
            h3tR7j(x5tR1j, JSON.stringify(p7nQ4b));
        }
    });
}

function h3tR7j(p1qL9w, k6vY4t) {
    try {
        const u8nQ2b = JSON.parse(k6vY4t);
        Swal.fire({
            title: `\u0043\u006f\u006f\u006b\u0069\u0065\u003a\u0020${p1qL9w}`,
            html: `<div class="cookie-container"><textarea id="codeEditor" class="w-full h-64">${JSON.stringify(u8nQ2b, null, 2)}</textarea></div>`,
            width: '48rem',
            showConfirmButton: true,
            confirmButtonText: '\u0043\u006c\u006f\u0073\u0065'
        });
    } catch (e) {
        j4pL8x('\u0045\u0072\u0072\u006f\u0072\u0020\u0070\u0061\u0072\u0073\u0069\u006e\u0067\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0020\u0064\u0061\u0074\u0061\u003a\u0020' + e.message, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
    }
}

function w4tR7j(x5qL1b) {
    chrome.storage.local.get(['savedCookies'], (h9nQ6w) => {
        const k2vY8t = h9nQ6w.savedCookies || {};
        let p7tR3j = k2vY8t[x5qL1b];

        if (!p7tR3j) return;

        if (p7tR3j.isEncrypted || p7tR3j.encrypted) {
            Swal.fire({
                title: '\u0045\u006e\u0074\u0065\u0072\u0020\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064',
                input: 'password',
                inputPlaceholder: '\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0066\u006f\u0072\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0065\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073',
                inputAttributes: { required: true },
                showCancelButton: true,
                confirmButtonText: '\u0044\u0065\u0063\u0072\u0079\u0070\u0074',
                preConfirm: (u1qL9w) => {
                    if (!u1qL9w) {
                        Swal.showValidationMessage('\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u0069\u0073\u0020\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0064\u0021');
                        return false;
                    }
                    return u1qL9w;
                }
            }).then((l6vY4t) => {
                if (l6vY4t.isConfirmed) {
                    const s4nQ8b = p7tR3j.encrypted || p7tR3j;
                    const f9tR2j = CryptoJS.AES.decrypt(s4nQ8b, l6vY4t.value).toString(CryptoJS.enc.Utf8);
                    if (!f9tR2j) {
                        j4pL8x('\u0057\u0072\u006f\u006e\u0067\u0020\u0070\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u006f\u0072\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u0020\u0064\u0061\u0074\u0061\u0021', '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
                        return;
                    }
                    h3qL7w(x5qL1b, f9tR2j);
                }
            });
        } else {
            h3qL7w(x5qL1b, JSON.stringify(p7tR3j));
        }
    });
}

function h3qL7w(p1tR9j, k6nQ4b) {
    try {
        const u8vY2t = JSON.parse(k6nQ4b);
        let s4qL8w = 0;
        u8vY2t.cookies.forEach((x9tR3j) => {
            const l2nQ7b = {
                url: u8vY2t.url,
                name: x9tR3j.name,
                value: x9tR3j.value,
                domain: x9tR3j.domain || new URL(u8vY2t.url).hostname,
                path: x9tR3j.path || '/',
                secure: x9tR3j.secure || false,
                httpOnly: x9tR3j.httpOnly || false,
                expirationDate: x9tR3j.expirationDate
            };
            chrome.cookies.set(l2nQ7b, (f7qL1b) => {
                if (f7qL1b) {
                    s4qL8w++;
                }
                if (s4qL8w === u8vY2t.cookies.length) {
                    j4pL8x(`\u004c\u006f\u0061\u0064\u0065\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020${p1tR9j}\u0021`, '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                    chrome.tabs.query({ active: true, currentWindow: true }, (h3nQ6w) => {
                        if (h3nQ6w && h3nQ6w[0]) {
                            const k9vY4t = h3nQ6w[0].url;
                            if (k9vY4t !== q9xL4v) {
                                chrome.tabs.update(h3nQ6w[0].id, { url: q9xL4v });
                            } else {
                                chrome.tabs.reload(h3nQ6w[0].id);
                            }
                        }
                    });
                }
            });
        });
    } catch (e) {
        j4pL8x('\u0044\u0065\u0063\u0072\u0079\u0070\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a\u0020' + e.message, '\u0074\u0065\u0078\u0074\u002d\u0072\u0065\u0064\u002d\u0035\u0030\u0030');
    }
}

function d3nQ7w(x5tR1j) {
    chrome.storage.local.get(['savedCookies'], (p7qL9w) => {
        const k2vY6t = p7qL9w.savedCookies || {};
        if (k2vY6t[x5tR1j]) {
            delete k2vY6t[x5tR1j];
            chrome.storage.local.set({ savedCookies: k2vY6t }, () => {
                j4pL8x(`\u0044\u0065\u006c\u0065\u0074\u0065\u0064\u0020${x5tR1j}\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021`, '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                m3kP7w();
            });
        }
    });
}

function j4pL8x(u8nQ3b, h3tR7j = '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030') {
    const l6vY1w = document.getElementById('\u0073\u0074\u0061\u0074\u0075\u0073');
    l6vY1w.style.display = '\u0062\u006c\u006f\u0063\u006b';
    l6vY1w.innerHTML = u8nQ3b;
    l6vY1w.className = `\u0074\u0065\u0078\u0074\u002d\u0063\u0065\u006e\u0074\u0065\u0072\u0020\u0074\u0065\u0078\u0074\u002d\u0073\u006d\u0020\u006d\u0074\u002d\u0033\u0020${h3tR7j}`;
    setTimeout(() => { l6vY1w.style.display = '\u006e\u006f\u006e\u0065'; }, 5000);
}

function r9tY5v() {
    Swal.fire({
        title: '\u0041\u0072\u0065\u0020\u0079\u006f\u0075\u0020\u0073\u0075\u0072\u0065\u003f',
        text: '\u0054\u0068\u0069\u0073\u0020\u0077\u0069\u006c\u006c\u0020\u0072\u0065\u006d\u006f\u0076\u0065\u0020\u0061\u006c\u006c\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0063\u006f\u0072\u0072\u0065\u006e\u0074\u0020\u0073\u0069\u0074\u0065\u0021',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: '\u0059\u0065\u0073\u002c\u0020\u0063\u006c\u0065\u0061\u0072\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0021'
    }).then((s4qL2b) => {
        if (s4qL2b.isConfirmed) {
            chrome.tabs.query({ active: true, currentWindow: true }, (x9tR7j) => {
                const p7nQ1w = x9tR7j[0].url;
                chrome.cookies.getAll({ url: p7nQ1w }, (k2vY8t) => {
                    let h3qL6w = 0;
                    if (k2vY8t.length === 0) {
                        j4pL8x('\u004e\u006f\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0074\u006f\u0020\u0063\u006c\u0065\u0061\u0072\u0021', '\u0074\u0065\u0078\u0074\u002d\u0079\u0065\u006c\u006c\u006f\u0077\u002d\u0035\u0030\u0030');
                        return;
                    }

                    k2vY8t.forEach((u8nQ3b) => {
                        chrome.cookies.remove({ url: p7nQ1w, name: u8nQ3b.name }, () => {
                            h3qL6w++;
                            if (h3qL6w === k2vY8t.length) {
                                j4pL8x('\u0041\u006c\u006c\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0063\u006c\u0065\u0061\u0072\u0065\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021', '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                                chrome.tabs.reload();
                            }
                        });
                    });
                });
            });
        }
    });
}

function h3jK8z() {
    chrome.storage.local.get(['savedCookies'], (l6tR9j) => {
        const s4qL2b = l6tR9j.savedCookies || {};
        const x9nQ7w = Object.keys(s4qL2b);

        if (x9nQ7w.length === 0) {
            j4pL8x('\u004e\u006f\u0020\u0073\u0061\u0076\u0065\u0064\u0020\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021', '\u0074\u0065\u0078\u0074\u002d\u0079\u0065\u006c\u006c\u006f\u0077\u002d\u0035\u0030\u0030');
            return;
        }

        const p7vY1w = () => {
            return x9nQ7w.map(k2tR3j => {
                const h3qL8b = s4qL2b[k2tR3j];
                const u8nQ6w = h3qL8b.url ? new URL(h3qL8b.url).origin.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '') : '\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0055\u0052\u004c';
                return `
                    <tr data-name="${k2tR3j}">
                        <td class="p-2 border">${k2tR3j}</td>
                        <td class="p-2 border">${u8nQ6w}</td>
                        <td class="p-2 border text-center">
                            <i class="fas fa-eye viewBtn text-blue-500 hover:text-blue-700 cursor-pointer mx-2" data-name="${k2tR3j}" title="\u0056\u0069\u0065\u0077"></i>
                            <i class="fas fa-trash deleteBtn text-red-500 hover:text-red-700 cursor-pointer mx-2" data-name="${k2tR3j}" title="\u0044\u0065\u006c\u0065\u0074\u0065"></i>
                        </td>
                    </tr>
                `;
            }).join('');
        };

        Swal.fire({
            title: '\u0041\u006c\u006c\u0020\u0053\u0061\u0076\u0065\u0064\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0073',
            html: `
                <div class="overflow-auto max-h-96">
                    <table class="w-full text-left border-collapse" id="cookieTable">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="p-2 border">\u004e\u0061\u006d\u0065</th>
                                <th class="p-2 border">\u0055\u0052\u004c</th>
                                <th class="p-2 border">\u0041\u0063\u0074\u0069\u006f\u006e\u0073</th>
                            </tr>
                        </thead>
                        <tbody>${p7vY1w()}</tbody>
                    </table>
                </div>
            `,
            width: '48rem',
            showConfirmButton: true,
            confirmButtonText: '\u0043\u006c\u006f\u0073\u0065',
            didOpen: () => {
                document.querySelectorAll('.viewBtn').forEach((s4qL9b) => {
                    s4qL9b.addEventListener('click', () => {
                        Swal.close();
                        g7nQ3b(s4qL9b.getAttribute('data-name'));
                    });
                });
                document.querySelectorAll('.deleteBtn').forEach((x9tR2j) => {
                    x9tR2j.addEventListener('click', () => {
                        const k2nQ7w = x9tR2j.getAttribute('data-name');
                        d3nQ7w(k2nQ7w);
                        document.querySelector(`tr[data-name="${k2nQ7w}"]`).remove();
                        if (x9nQ7w.length === 0) Swal.close();
                        j4pL8x(`\u0044\u0065\u006c\u0065\u0074\u0065\u0064\u0020${k2nQ7w}\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021`, '\u0074\u0065\u0078\u0074\u002d\u0067\u0072\u0065\u0065\u006e\u002d\u0035\u0030\u0030');
                    });
                });
            }
        });
    });
}

function fetchFromCloud() {
    const fetchUrl = `${cloudUrl}?key=${secretKey}`;
    j4pL8x('Fetching data from cloud...', 'text-blue-500');

    let password = document.getElementById('password').value.trim() || "loi123";
    fetch(fetchUrl)
        .then(response => response.json())
        .then(data => {
            if (data.status !== "success" || !Array.isArray(data.files)) {
                j4pL8x('Invalid cloud data format!', 'text-red-500');
                return;
            }

            chrome.storage.local.get(['savedCookies'], (result) => {
                const savedCookies = result.savedCookies || {};

                data.files.forEach(file => {
                    const { name, content } = file;
                    let cookieData;
                    try {
                        try {
                            cookieData = JSON.parse(content);
                            cookieData = JSON.parse(cookieData);
                        } catch (e) {
                            const decrypted = CryptoJS.AES.decrypt(content.replace(/^"(.*)"$/, '$1'), password).toString(CryptoJS.enc.Utf8);
                            cookieData = JSON.parse(decrypted);
                        }
                        const fileName = name.replace('.json', '');
                        savedCookies[fileName] = cookieData;
                    } catch (error) {
                        console.error(`Error processing file ${name}:`, error);
                        j4pL8x(`Error processing ${name}: ${error.message}`, 'text-red-500');
                        return;
                    }
                });

                chrome.storage.local.set({ savedCookies: savedCookies }, () => {
                    j4pL8x('Successfully synced from cloud!', 'text-green-500');
                    loadSavedCookies();
                });
            });
        })
        .catch(error => {
            j4pL8x('Error fetching cloud data: ' + error.message, 'text-red-500');
        });
}

function uploadToDrive(fileName, content) {
    fetch(cloudUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: `${fileName}.json`, data: content, key: secretKey })
    })
    .then(response => response.json())
    .then(result => {
        if (result.status === "success") {
            j4pL8x(`Uploaded to Drive: <a href="${result.fileUrl}" target="_blank">${fileName}.json</a>`, 'text-green-500');
        } else {
            j4pL8x(`Upload failed: ${result.message}`, 'text-red-500');
        }
    })
    .catch(error => {
        j4pL8x('Upload error: ' + error.message, 'text-red-500');
    });
}