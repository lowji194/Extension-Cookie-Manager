'use strict';
importScripts('crypto-js.min.js');

// ── CÀI CỨNG API URL VÀ MẬT KHẨU TẠI ĐÂY (bỏ trống '' nếu không dùng) ────────
const HARDCODED_API_URL  = 'https://theloi.io.vn/ajx/cookiemanager/api.php';  // Ví dụ: 'https://script.google.com/macros/s/xxx/exec'
const HARDCODED_PASSWORD = 'loi@1234';  // Ví dụ: 'matkhau123'
// ─────────────────────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log('Cookie Manager v4 installed');
});

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === 'getActiveTab')              { getActiveTab(sendResponse);                                       return true; }
  if (req.action === 'getAllPersistentCookies')   { getAllPersistentCookies(sendResponse);                            return true; }
  if (req.action === 'getCookiesForUrl')    { getCookiesForUrl(req.url, sendResponse);                          return true; }
  if (req.action === 'saveCookies')         { saveCookies(req.label, req.origin, req.cookies, sendResponse);    return true; }
  if (req.action === 'getSavedAll')         { getSavedAll(sendResponse);                                        return true; }
  if (req.action === 'restoreCookies')      { restoreCookies(req.cookies, sendResponse);                        return true; }
  if (req.action === 'deleteSnapshot')      { deleteSnapshot(req.key, sendResponse);                            return true; }
  if (req.action === 'deleteCookie')        { deleteCookieByName(req.cookieName, req.url, sendResponse);        return true; }
  if (req.action === 'logoutCookies')       { logoutCookies(req.cookies, sendResponse);                         return true; }
  if (req.action === 'autoUploadCloud')     { autoUploadCloud(req, sendResponse);                               return true; }
  if (req.action === 'uploadAllToCloud')    { uploadAllToCloud(req, sendResponse);                              return true; }
  if (req.action === 'getHardcodedConfig')  { getHardcodedConfig(sendResponse);                                 return true; }
  if (req.action === 'deleteFromCloud')     { deleteFromCloud(req, sendResponse);								return true; }
  if (req.action === 'backupToCloud')       { backupToCloud(req, sendResponse);                              return true; }
  if (req.action === 'restoreFromCloud')    { restoreFromCloud(req, sendResponse);                           return true; }
  if (req.action === 'listBackupsOnCloud')  { listBackupsOnCloud(req, sendResponse);                        return true; }
});

function getHardcodedConfig(cb) {
  cb({
    apiUrl:   HARDCODED_API_URL   || null,
    password: HARDCODED_PASSWORD  || null
  });
}

async function getActiveTab(cb) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) { cb({ success: false, error: 'Không lấy được tab' }); return; }
    const url = new URL(tab.url);
    cb({ success: true, tabId: tab.id, url: tab.url, origin: url.origin, hostname: url.hostname, title: tab.title });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function getAllPersistentCookies(cb) {
  try {
    const all = await chrome.cookies.getAll({});
    // Persistent = có expirationDate (session cookie thì không có hoặc session=true)
    const persistent = all.filter(c => !c.session && c.expirationDate && c.expirationDate > Date.now() / 1000);
    cb({ success: true, cookies: persistent, total: all.length });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function getActiveTab(cb) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) { cb({ success: false, error: 'Không lấy được tab' }); return; }
    const url = new URL(tab.url);
    cb({ success: true, tabId: tab.id, url: tab.url, origin: url.origin, hostname: url.hostname, title: tab.title });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function getCookiesForUrl(url, cb) {
  try {
    const cookies = await chrome.cookies.getAll({ url });
    const seen = new Set();
    const unique = cookies.filter(c => {
      const k = c.name + '|' + c.domain;
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
    cb({ success: true, cookies: unique });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function saveCookies(label, origin, cookies, cb) {
  try {
    const res = await chrome.storage.local.get('snapshots');
    const snapshots = res.snapshots || {};
    const key = origin + '::' + label;
    snapshots[key] = { key, label, origin, cookies, savedAt: new Date().toISOString(), count: cookies.length };
    await chrome.storage.local.set({ snapshots });
    cb({ success: true, key });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function getSavedAll(cb) {
  try {
    const res = await chrome.storage.local.get('snapshots');
    cb({ success: true, snapshots: res.snapshots || {} });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function restoreCookies(cookies, cb) {
  try {
    let ok = 0, fail = 0;
    for (const c of cookies) {
      try {
        const base = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
        const det = {
          url: 'https://' + base + c.path,
          name: c.name, value: c.value,
          domain: c.domain, path: c.path,
          secure: c.secure, httpOnly: c.httpOnly,
          sameSite: c.sameSite || 'unspecified'
        };
        if (!c.session && c.expirationDate) det.expirationDate = c.expirationDate;
        await chrome.cookies.set(det);
        ok++;
      } catch { fail++; }
    }
    cb({ success: true, restored: ok, failed: fail });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function deleteSnapshot(key, cb) {
  try {
    const res = await chrome.storage.local.get('snapshots');
    const s = res.snapshots || {};
    delete s[key];
    await chrome.storage.local.set({ snapshots: s });
    cb({ success: true });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function deleteCookieByName(name, url, cb) {
  try {
    const cookies = await chrome.cookies.getAll({ url, name });
    for (const c of cookies) {
      const base = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
      await chrome.cookies.remove({ url: 'https://' + base + c.path, name });
    }
    cb({ success: true });
  } catch(e) { cb({ success: false, error: e.message }); }
}

async function logoutCookies(cookies, cb) {
  try {
    let expired = 0, fail = 0;
    const pastTime = Math.floor(Date.now() / 1000) - 1;
    for (const c of cookies) {
      try {
        const base = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
        const cookieUrl = (c.secure ? 'https' : 'http') + '://' + base + (c.path || '/');
        await chrome.cookies.set({
          url: cookieUrl, name: c.name, value: c.value,
          domain: c.domain, path: c.path || '/',
          secure: c.secure || false, httpOnly: c.httpOnly || false,
          sameSite: c.sameSite || 'unspecified',
          expirationDate: pastTime
        });
        expired++;
      } catch { fail++; }
    }
    cb({ success: true, expired, failed: fail });
  } catch(e) { cb({ success: false, error: e.message }); }
}

// ─── AUTO UPLOAD (single snapshot) ───────────────────────────────────────────
async function autoUploadCloud(req, cb) {
  cb({ success: true }); // Trả về ngay để không block popup

  try {
    const apiUrl = HARDCODED_API_URL || (await chrome.storage.local.get('cloudApiUrl')).cloudApiUrl;
    if (!apiUrl) {
      console.log('[AutoUpload] Không có API URL');
      return;
    }

    const passphrase = HARDCODED_PASSWORD || (await chrome.storage.local.get('cloudAutoKey')).cloudAutoKey;
    if (!passphrase) {
      console.log('[AutoUpload] Không có passphrase');
      return;
    }

    const { cookies, hostname, label } = req;

    let cookieData = JSON.stringify(cookies);
    if (passphrase) {
      cookieData = CryptoJS.AES.encrypt(JSON.stringify(cookies), passphrase).toString();
    }

    const payload = {
      action: "save",
      web: hostname || '',
      name: label,
      time: new Date().toISOString(),
      cookie: cookieData,
      timerISO: ""
    };

    console.log("📤 AutoUpload payload:", payload);

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    console.log("📥 AutoUpload response:", result);

    if (result.success) {
      console.log(`✅ Đã upload thành công: ${label}`);
    } else {
      console.warn(`⚠️ Upload thất bại: ${result.error}`);
    }
  } catch (e) {
    console.error('[AutoUpload] Lỗi:', e.message);
  }
}

// ─── XOÁ SNAPSHOT TRÊN CLOUD ─────────────────────────────────────────────────
async function deleteFromCloud(req, cb) {
  cb({ success: true });

  try {
    const apiUrl = HARDCODED_API_URL || (await chrome.storage.local.get('cloudApiUrl')).cloudApiUrl;
    if (!apiUrl) return console.log('[DeleteCloud] No API URL');

    const { web, name } = req;
    if (!web || !name) return console.log('[DeleteCloud] Missing web or name');

    const payload = {
      action: "delete",
      web: web,
      name: name
    };

    console.log("🗑 DeleteCloud payload:", payload);

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    console.log("🗑 DeleteCloud response:", result);

  } catch (e) {
    console.error('[DeleteCloud] Error:', e.message);
  }
}

// ─── UPLOAD ALL ─────────────────────────────────────────────────────────────
async function uploadAllToCloud(req, cb) {
  try {
    const stored = await chrome.storage.local.get(['cloudApiUrl', 'cloudAutoKey', 'snapshots', 'timers']);
    const apiUrl = HARDCODED_API_URL || stored.cloudApiUrl;
    if (!apiUrl) return cb({ success: false, error: 'Chưa có API URL' });

    const passphrase = HARDCODED_PASSWORD || stored.cloudAutoKey || req.passphrase;
    if (!passphrase) return cb({ success: false, error: 'Chưa có mật khẩu' });

    const snapshots = stored.snapshots || {};
    const keys = Object.keys(snapshots);
    if (!keys.length) return cb({ success: false, error: 'Không có snapshot' });

    let ok = 0, fail = 0, errors = [];

    for (const k of keys) {
      const s = snapshots[k];
      try {
        const hostname = (() => { 
          try { return new URL(s.origin).hostname; } 
          catch { return s.origin; } 
        })();

        let cookieData = JSON.stringify(s.cookies);
        if (passphrase) {
          cookieData = CryptoJS.AES.encrypt(JSON.stringify(s.cookies), passphrase).toString();
        }

        const payload = {
          action: "save",
          web: hostname,
          name: s.label,
          time: s.savedAt || new Date().toISOString(),
          cookie: cookieData,
          timerISO: ""
        };

        const res = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (data.success) ok++;
        else {
          fail++;
          errors.push(s.label + ": " + (data.error || 'unknown'));
        }
      } catch (e) {
        fail++;
        errors.push(s.label + ": " + e.message);
      }
    }

    cb({ success: true, ok, fail, total: keys.length, errors });

  } catch (e) {
    cb({ success: false, error: e.message });
  }
}

// ─── BACKUP LÊN CLOUD ────────────────────────────────────────────────────────
async function backupToCloud(req, cb) {
  try {
    const apiUrl = HARDCODED_API_URL || (await chrome.storage.local.get('cloudApiUrl')).cloudApiUrl;
    if (!apiUrl) return cb({ success: false, error: 'Chưa có API URL — cấu hình ở tab Cloud' });

    const passphrase = HARDCODED_PASSWORD || (await chrome.storage.local.get('cloudAutoKey')).cloudAutoKey || req.passphrase;
    if (!passphrase) return cb({ success: false, error: 'Chưa có mật khẩu — cấu hình ở tab Cloud' });

    const { label, payload } = req;
    if (!label || !payload) return cb({ success: false, error: 'Thiếu label hoặc payload' });

    // Mã hoá toàn bộ payload bằng AES
    payload.encrypted = true;
    const encrypted = CryptoJS.AES.encrypt(JSON.stringify(payload), passphrase).toString();
    const fileData = JSON.stringify({ magic: 'CMBAK1', version: 2, encrypted: true, data: encrypted, exportedAt: new Date().toISOString() });

    // Tạo tên file .bak từ label
    const safeLabel = label.replace(/[^a-zA-Z0-9._-]/g, '_');
    const filename = safeLabel.endsWith('.bak') ? safeLabel : safeLabel + '.bak';

    const body = {
      action:   'backup_upload',
      filename: filename,
      data:     fileData
    };

    const res  = await fetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json();
    if (data.success) cb({ success: true, filename: data.filename });
    else cb({ success: false, error: data.error || 'Server trả về lỗi' });
  } catch (e) {
    cb({ success: false, error: e.message });
  }
}

// ─── LIỆT KÊ BACKUP TRÊN CLOUD ───────────────────────────────────────────────
async function listBackupsOnCloud(req, cb) {
  try {
    const apiUrl = HARDCODED_API_URL || (await chrome.storage.local.get('cloudApiUrl')).cloudApiUrl;
    if (!apiUrl) return cb({ success: false, error: 'Chưa có API URL' });

    const res  = await fetch(apiUrl + '?action=backup_list');
    const data = await res.json();
    if (data.success) cb({ success: true, backups: data.backups || [] });
    else cb({ success: false, error: data.error || 'Lỗi khi tải danh sách backup' });
  } catch (e) {
    cb({ success: false, error: e.message });
  }
}

// ─── RESTORE TỪ CLOUD ────────────────────────────────────────────────────────
async function restoreFromCloud(req, cb) {
  try {
    const apiUrl = HARDCODED_API_URL || (await chrome.storage.local.get('cloudApiUrl')).cloudApiUrl;
    if (!apiUrl) return cb({ success: false, error: 'Chưa có API URL' });

    const passphrase = HARDCODED_PASSWORD || (await chrome.storage.local.get('cloudAutoKey')).cloudAutoKey || req.passphrase;
    if (!passphrase) return cb({ success: false, error: 'Chưa có mật khẩu để giải mã' });

    const { label } = req;
    if (!label) return cb({ success: false, error: 'Thiếu tên backup' });

    // label ở đây là filename (.bak)
    const res  = await fetch(apiUrl + `?action=backup_download&filename=${encodeURIComponent(label)}`);
    const data = await res.json();
    if (!data.success || !data.data) return cb({ success: false, error: data.error || 'Không tìm thấy backup' });

    // Parse file .bak JSON
    let fileObj;
    try {
      fileObj = JSON.parse(data.data);
    } catch {
      return cb({ success: false, error: 'File backup bị hỏng (không phải JSON hợp lệ)' });
    }

    if (fileObj.magic !== 'CMBAK1') {
      return cb({ success: false, error: 'File không đúng định dạng backup (sai magic)' });
    }

    // Giải mã nếu được mã hoá
    let payload;
    if (fileObj.encrypted) {
      try {
        const bytes = CryptoJS.AES.decrypt(fileObj.data, passphrase);
        const plain = bytes.toString(CryptoJS.enc.Utf8);
        if (!plain) throw new Error('empty');
        payload = JSON.parse(plain);
      } catch {
        return cb({ success: false, error: 'Sai mật khẩu hoặc dữ liệu bị hỏng' });
      }
    } else {
      payload = fileObj;
    }

    cb({ success: true, payload, savedAt: fileObj.exportedAt || data.created_at || '' });
  } catch (e) {
    cb({ success: false, error: e.message });
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function hostnameToSheet(hostname) {
  const parts = (hostname || '').replace('www.', '').split('.');
  const name  = parts[0] || 'Unknown';
  return name.charAt(0).toUpperCase() + name.slice(1);
}

// CryptoJS AES encrypt — tương thích với popup.js (CryptoJS.AES.encrypt/decrypt)
function aesEncrypt(plaintext, passphrase) {
  return CryptoJS.AES.encrypt(plaintext, passphrase).toString();
}

function sha256fp(str) {
  return CryptoJS.SHA256(str).toString().substring(0, 8).toUpperCase();
}