'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
let activeTab    = null;
let liveCookies  = [];
let filteredLive = [];
let timerKey     = '';
let tickTimer    = null;

// ── Toast system ──────────────────────────────────────────────────────────────
(function injectToastCSS() {
  if (document.getElementById('toast-style')) return;
  const s = document.createElement('style');
  s.id = 'toast-style';
  s.textContent = `
    /* ẨN SCROLL NGOÀI - CHỈ SCROLL BÊN TRONG */
    body, html {
      overflow: hidden !important;
      height: 100%;
    }

    /* Header và Tabs luôn ghim */
    .hdr, .tabs {
      position: sticky;
      top: 0;
      z-index: 100;
      background: var(--surface);
    }
    .tabs {
      z-index: 101;
    }

    /* Panel nội dung */
    .panel {
      overflow-y: auto !important;
      flex: 1 1 0;
      min-height: 0;
      max-height: calc(100vh - 140px);   /* header + tabs + footer */
      padding-right: 8px;               /* Tránh scroll bar che nội dung */
      scrollbar-width: thin;
      scrollbar-color: #4b5563 transparent;
    }

    /* Scroll đẹp cho Chrome/Edge/Safari */
    .panel::-webkit-scrollbar {
      width: 6px;
    }
    .panel::-webkit-scrollbar-track {
      background: transparent;
    }
    .panel::-webkit-scrollbar-thumb {
      background: #4b5563;
      border-radius: 10px;
    }
    .panel::-webkit-scrollbar-thumb:hover {
      background: #6b7280;
    }

    /* Saved content đặc biệt */
    #saved-content {
      max-height: none;
      padding-right: 8px;
    }

    /* Toast */
    #toast-container {
      position: fixed; 
      bottom: 14px; 
      right: 14px; 
      z-index: 99999;
      display: flex; 
      flex-direction: column-reverse; 
      gap: 8px;
      pointer-events: none;
    }
    .toast-item {
      display: flex; align-items: center; gap: 9px;
      padding: 9px 13px; border-radius: 10px; min-width: 180px; max-width: 270px;
      font-size: 12px; font-weight: 500; color: #e2e8f0;
      background: #1e2233; border: 1px solid rgba(255,255,255,.1);
      box-shadow: 0 4px 18px rgba(0,0,0,.45);
      animation: toastIn .2s ease, toastOut .25s ease forwards;
      animation-delay: 0s, 2.8s;
      pointer-events: auto;
    }
    .toast-item.warn  { border-color: rgba(245,197,66,.35); }
    .toast-item.error { border-color: rgba(245,101,101,.35); animation-delay: 0s, 4s; }
    .toast-icon { font-size: 15px; flex-shrink: 0; }
    .toast-body { display: flex; flex-direction: column; gap: 1px; }
    .toast-title { font-weight: 600; }
    .toast-text  { font-size: 11px; color: #718096; }

    @keyframes toastIn  { from { opacity:0; transform:translateY(8px) } to { opacity:1; transform:translateY(0) } }
    @keyframes toastOut { from { opacity:1 } to { opacity:0; transform:translateY(4px) } }
  `;
  document.head.appendChild(s);

  const c = document.createElement('div');
  c.id = 'toast-container';
  document.body.appendChild(c);
})();

function showToast(type, title, text) {
  const icons = { success: '✅', warning: '⚠️', error: '❌', info: 'ℹ️' };
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = 'toast-item' + (type === 'warning' ? ' warn' : type === 'error' ? ' error' : '');
  t.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ️'}</span>
    <div class="toast-body">
      <span class="toast-title">${title}</span>
      ${text ? `<span class="toast-text">${text}</span>` : ''}
    </div>`;
  const delay = type === 'error' ? 4200 : 2750;
  c.appendChild(t);
  setTimeout(() => t.remove(), delay);
  return Promise.resolve();
}

// ── SweetAlert2 helpers ───────────────────────────────────────────────────────
function swalSuccess(title, text) { return showToast('success', title, text); }
function swalWarn(title, text)    { return showToast('warning', title, text); }
function swalError(title, text) {
  return Swal.fire({ icon: 'error', title, text: text || '', confirmButtonText: 'OK' });
}
function swalConfirm(title, text, confirmText = 'Xác nhận', icon = 'question') {
  return Swal.fire({
    icon, title, text,
    showCancelButton: true,
    confirmButtonText: confirmText,
    cancelButtonText: 'Huỷ',
    reverseButtons: true
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const show = el => { el.style.display = ''; };
const hide = el => { el.style.display = 'none'; };
const esc  = s  => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

function btn(text, cls, fn) {
  const b = document.createElement('button');
  b.className = cls; b.innerHTML = text;
  b.addEventListener('click', fn);
  return b;
}
function pad(n) { return n < 10 ? '0' + n : '' + n; }
function fmtCountdown(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h > 0) return h + 'g ' + pad(m) + 'p ' + pad(sec) + 'g';
  if (m > 0) return m + 'p ' + pad(sec) + 'g';
  return sec + 'g';
}

// SVG spinner HTML
const SVG_SPINNER = `<svg class="svg-spin" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"
    stroke-dasharray="40 20" opacity="0.25"/>
  <path d="M12 3a9 9 0 0 1 9 9" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
</svg>`;

// ── Tabs ──────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $('panel-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'live')   initLive();
    if (tab.dataset.tab === 'saved')  loadSaved();
    if (tab.dataset.tab === 'cloud')  initCloud();
    if (tab.dataset.tab === 'backup') initBackup();
  });
});

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ action: 'getActiveTab' }, res => {
  if (res && res.success) {
    activeTab = res;
    
    const dot = '<span class="dot" style="display:inline-block;width:7px;height:7px;background:var(--success);border-radius:50%;margin-right:6px;vertical-align:middle;"></span>';
    const hostname = res.hostname || res.origin || 'Unknown';
    
    $('hdr-sub').innerHTML = dot + esc(hostname);
    $('hdr-badge').style.display = '';
  } else {
    $('hdr-sub').textContent = 'Không xác định được trang';
  }
  loadSaved();
});

// ── CLOUD REQUEST HELPER (gọi qua background) ───────────────────────────────
async function cloudRequest(action, body = null, method = 'POST') {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({
      action: 'cloudRequest',
      method: method,
      apiAction: action,     // action của PHP API
      body: body,
      keyFp: _sessionKey ? keyFingerprint(_sessionKey) : null
    }, resolve);
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB: COOKIE ĐÃ LƯU
// ═══════════════════════════════════════════════════════════════════════════════
function loadSaved() {
  $('saved-content').innerHTML = '';
  hide($('saved-empty'));
  show($('saved-loading'));

  chrome.runtime.sendMessage({ action: 'getSavedAll' }, res => {
    hide($('saved-loading'));
    if (!res || !res.success) { swalError('Lỗi', 'Không tải được dữ liệu'); return; }

    const snaps = res.snapshots || {};
    const keys  = Object.keys(snaps);
    if (!keys.length) { show($('saved-empty')); return; }

	chrome.storage.local.get('timers', tRes => {
	  const timers = (tRes && tRes.timers) || {};
	  const groups = {};

	  keys.forEach(k => {
		const s = snaps[k];
		if (!groups[s.origin]) groups[s.origin] = [];
		groups[s.origin].push(s);
	  });

	  const container = $('saved-content');
	  const now = Date.now();

	  let originOrder = Object.keys(groups).sort((a, b) => {
		if (activeTab && a === activeTab.origin) return -1;
		if (activeTab && b === activeTab.origin) return 1;
		return a.localeCompare(b);
	  });

	  // Nếu toggle bật → chỉ giữ lại web hiện tại
	  if (onlyCurrentSite && activeTab) {
		originOrder = originOrder.filter(origin => origin === activeTab.origin);
	  }

	  if (!originOrder.length) {
		show($('saved-empty'));
		hide($('saved-loading'));
		return;
	  }

      originOrder.forEach(origin => {
        const group    = groups[origin];
        const hostname = (() => { try { return new URL(origin).hostname; } catch { return origin; } })();
        const isCurrent = activeTab && origin === activeTab.origin;

        const label = document.createElement('div');
        label.className = 'site-label';
        label.innerHTML =
          '<img class="favicon" src="https://www.google.com/s2/favicons?sz=16&domain=' + esc(hostname) + '" />' +
          '<span>' + esc(hostname) + '</span>' +
          (isCurrent ? '<span style="font-size:9px;background:rgba(86,212,154,.15);color:var(--success);padding:1px 6px;border-radius:10px;margin-left:auto;border:1px solid rgba(86,212,154,.3)">● Trang hiện tại</span>' : '');

        const groupDiv = document.createElement('div');
        groupDiv.className = 'site-group';
        groupDiv.appendChild(label);

        group.forEach(s => {
          const timer   = timers[s.key] || null;
          const timerOn = timer && now < timer.deadlineMs;
          const isImported = s.imported === true;
          const isCloud    = s.fromCloud === true;

          const card = document.createElement('div');
          card.className = 'scard' + (timerOn ? ' timer-on' : '') + (isCloud ? ' cloud-loaded' : (isImported ? ' imported' : ''));
          card.dataset.key = s.key;

          const row1 = document.createElement('div');
          row1.className = 'scard-row1';

          const dot = document.createElement('span');
          dot.className = 'status-dot ' + (timerOn ? 'red' : (isCloud ? 'purple' : (isImported ? 'blue' : 'green')));
          dot.dataset.dotKey = s.key;

          const nameEl = document.createElement('div');
          nameEl.className = 'scard-name';
          nameEl.textContent = s.label;
          nameEl.title = s.label;

          row1.appendChild(dot);
          row1.appendChild(nameEl);

          if (isCloud) {
            const cb2 = document.createElement('span');
            cb2.className = 'tag-badge tag-cloud';
            cb2.textContent = '☁ Cloud';
            row1.appendChild(cb2);
          } else if (isImported) {
            const ib = document.createElement('span');
            ib.className = 'tag-badge tag-imported';
            ib.textContent = '📥 Import';
            row1.appendChild(ib);
          }

          if (timerOn) {
            const badge = document.createElement('span');
            badge.className = 'tag-timer';
            badge.dataset.badgeKey   = s.key;
            badge.dataset.deadlineMs = timer.deadlineMs;
            badge.textContent = '⏰ ' + fmtCountdown(timer.deadlineMs - now);
            row1.appendChild(badge);
          }

          const info = document.createElement('div');
          info.className = 'scard-info';
          const savedDate = new Date(s.savedAt).toLocaleString('vi-VN');
          info.innerHTML = '<span>🍪 ' + s.count + ' cookies</span><span>🕒 ' + esc(savedDate) + '</span>';
          if (timer && timer.note) {
            const ns = document.createElement('span');
            ns.textContent = '📝 ' + timer.note;
            info.appendChild(ns);
          }

          const acts = document.createElement('div');
          acts.className = 'scard-actions';

          const restoreBtn = btn('↩ Khôi phục', 'btn btn-primary btn-sm',  () => restoreSnap(s));
          const copyBtn    = btn('📋 Copy',      'btn btn-ghost btn-sm',    () => copySnap(s.cookies));
          const exportBtn  = btn('⬇ JSON',       'btn btn-info btn-sm',     () => exportSnap(s));
          const timerBtn   = btn('🕒', 'btn btn-icon w', () => openTimer(s.key, s.label, timer));
          timerBtn.title   = timer ? 'Sửa hẹn giờ' : 'Đặt hẹn giờ';

          const delBtn = document.createElement('button');
          delBtn.className = 'btn-delete';
          delBtn.innerHTML = '🗑 Xoá';
          delBtn.title     = 'Xoá snapshot này';
          delBtn.addEventListener('click', () => deleteSnap(s.key));

          acts.appendChild(restoreBtn);
          acts.appendChild(copyBtn);
          acts.appendChild(exportBtn);
          acts.appendChild(timerBtn);
          acts.appendChild(delBtn);

          card.appendChild(row1);
          card.appendChild(info);
          card.appendChild(acts);
          groupDiv.appendChild(card);
        });

        container.appendChild(groupDiv);
      });

      startTick();
    });
  });
}

// ── Countdown tick ────────────────────────────────────────────────────────────
function startTick() {
  if (tickTimer) clearInterval(tickTimer);
  tickTimer = setInterval(() => {
    const badges = document.querySelectorAll('.tag-timer[data-deadline-ms]');
    if (!badges.length) return;
    const now = Date.now();
    badges.forEach(badge => {
      const dl   = parseInt(badge.dataset.deadlineMs, 10);
      const diff = dl - now;
      if (diff <= 0) {
        const key  = badge.dataset.badgeKey;
        badge.remove();
        const card = document.querySelector('.scard[data-key="' + key + '"]');
        if (card) {
          card.classList.remove('timer-on');
          const dot = card.querySelector('.status-dot[data-dot-key]');
          if (dot) dot.className = 'status-dot green';
        }
      } else {
        badge.textContent = '⏰ ' + fmtCountdown(diff);
      }
    });
  }, 1000);
}

// ── OVERWRITE MODAL (thuần JS, không dùng SweetAlert) ────────────────────────
function showOverwriteModal(siteSnaps, cookieCount, onChoose, onNew, onCancel) {
  // Xoá modal cũ nếu còn
  const old = document.getElementById('ow-modal-overlay');
  if (old) old.remove();

  const overlay = document.createElement('div');
  overlay.id = 'ow-modal-overlay';
  overlay.style.cssText = [
    'position:fixed;inset:0;z-index:9999',
    'background:rgba(0,0,0,.55)',
    'display:flex;align-items:center;justify-content:center',
    'animation:owFadeIn .15s ease'
  ].join(';');

  // Inject keyframe nếu chưa có
  if (!document.getElementById('ow-style')) {
    const st = document.createElement('style');
    st.id = 'ow-style';
    st.textContent = `
      @keyframes owFadeIn  { from { opacity:0 } to { opacity:1 } }
      @keyframes owSlideUp { from { opacity:0;transform:translateY(10px) } to { opacity:1;transform:translateY(0) } }
      #ow-modal { animation: owSlideUp .18s ease; }
      .ow-snap-btn {
        display:flex; align-items:center; justify-content:space-between;
        width:100%; padding:9px 12px; margin-bottom:6px;
        background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.09);
        border-radius:8px; cursor:pointer; transition:background .15s, border-color .15s;
        text-align:left;
      }
      .ow-snap-btn:hover { background:rgba(99,179,237,.13); border-color:rgba(99,179,237,.4); }
      .ow-snap-btn:active { background:rgba(99,179,237,.22); }
      .ow-snap-name { font-size:13px; font-weight:500; color:#e2e8f0; }
      .ow-snap-meta { font-size:10px; color:#718096; margin-top:2px; }
      .ow-snap-badge { font-size:10px; color:#68d391; background:rgba(104,211,145,.12);
        border:1px solid rgba(104,211,145,.25); border-radius:10px; padding:1px 7px; white-space:nowrap; }
      .ow-btn-new {
        width:100%; padding:8px; margin-top:4px;
        background:transparent; border:1px dashed rgba(255,255,255,.2);
        border-radius:8px; color:#a0aec0; font-size:12px; cursor:pointer;
        transition:background .15s, border-color .15s, color .15s;
      }
      .ow-btn-new:hover { background:rgba(255,255,255,.06); border-color:rgba(255,255,255,.35); color:#e2e8f0; }
    `;
    document.head.appendChild(st);
  }

  const modal = document.createElement('div');
  modal.id = 'ow-modal';
  modal.style.cssText = [
    'background:#1e2233; border:1px solid rgba(255,255,255,.1)',
    'border-radius:12px; padding:18px; width:290px; max-width:94vw',
    'box-shadow:0 8px 32px rgba(0,0,0,.5)'
  ].join(';');

  // Header
  const hdr = document.createElement('div');
  hdr.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:12px';
  hdr.innerHTML = `
    <div>
      <div style="font-size:13px;font-weight:600;color:#e2e8f0">🔄 Ghi đè snapshot</div>
      <div style="font-size:11px;color:#718096;margin-top:2px">
        Click để lưu ghi đè — <span style="color:#68d391">${cookieCount} cookies</span> hiện tại
      </div>
    </div>`;
  const closeBtn = document.createElement('button');
  closeBtn.innerHTML = '✕';
  closeBtn.style.cssText = 'background:none;border:none;color:#718096;font-size:16px;cursor:pointer;padding:2px 6px;border-radius:4px;line-height:1';
  closeBtn.addEventListener('click', () => { overlay.remove(); onCancel(); });
  hdr.appendChild(closeBtn);
  modal.appendChild(hdr);

  // Divider
  const div0 = document.createElement('div');
  div0.style.cssText = 'height:1px;background:rgba(255,255,255,.07);margin-bottom:10px';
  modal.appendChild(div0);

  // Danh sách snapshot — mỗi cái là 1 button click lưu luôn
  const list = document.createElement('div');
  list.style.cssText = 'max-height:220px;overflow-y:auto;padding-right:2px';
  siteSnaps.forEach(s => {
    const row = document.createElement('button');
    row.className = 'ow-snap-btn';
    const date = new Date(s.savedAt).toLocaleString('vi-VN');
    row.innerHTML = `
      <div>
        <div class="ow-snap-name">${esc(s.label)}</div>
        <div class="ow-snap-meta">🕒 ${date}</div>
      </div>
      <span class="ow-snap-badge">🍪 ${s.count}</span>`;
    row.addEventListener('click', () => { overlay.remove(); onChoose(s.label); });
    list.appendChild(row);
  });
  modal.appendChild(list);

  // Nút tạo mới
  const newBtn = document.createElement('button');
  newBtn.className = 'ow-btn-new';
  newBtn.innerHTML = '✏️ Nhập tên mới để tạo snapshot mới';
  newBtn.addEventListener('click', () => { overlay.remove(); onNew(); });
  modal.appendChild(newBtn);

  overlay.appendChild(modal);
  // Click ngoài → đóng
  overlay.addEventListener('click', e => { if (e.target === overlay) { overlay.remove(); onCancel(); } });
  document.body.appendChild(overlay);
}

// ── LƯU COOKIE + GỬI YÊU CẦU UPLOAD QUA BACKGROUND ─────────────────────
$('btn-save').addEventListener('click', async () => {
  const label = $('snap-name').value.trim();

  if (!activeTab) {
    swalError('Lỗi', 'Không xác định được trang hiện tại');
    return;
  }

  // Lấy cookies hiện tại
  const cookieRes = await new Promise(r =>
    chrome.runtime.sendMessage({ action: 'getCookiesForUrl', url: activeTab.url }, r)
  );
  if (!cookieRes || !cookieRes.success || !cookieRes.cookies?.length) {
    swalError('Không có cookie', 'Trang này chưa có cookie nào để lưu');
    return;
  }
  const cookies = cookieRes.cookies;

  // Input có tên → lưu thẳng
  if (label) {
    await doSaveCookies(label, cookies, false);
    return;
  }

  // Input trống → kiểm tra snapshot cũ của trang
  const snapsRes = await new Promise(r => chrome.storage.local.get('snapshots', r));
  const siteSnaps = Object.values(snapsRes.snapshots || {}).filter(s => s.origin === activeTab.origin);

  if (!siteSnaps.length) {
    // Chưa có snapshot nào → yêu cầu nhập tên
    $('snap-name').focus();
    $('snap-name').placeholder = 'Nhập tên snapshot...';
    $('snap-name').style.borderColor = 'rgba(245,101,101,.6)';
    setTimeout(() => { $('snap-name').style.borderColor = ''; }, 1500);
    return;
  }

  // Có snapshot cũ → hiện custom modal
  showOverwriteModal(
    siteSnaps,
    cookies.length,
    (chosenLabel) => doSaveCookies(chosenLabel, cookies, true),   // click item → ghi đè luôn
    () => { $('snap-name').focus(); $('snap-name').placeholder = 'Nhập tên snapshot mới...'; }, // nút tạo mới
    () => {}  // cancel
  );
});

// ── Hàm thực thi lưu cookie (dùng chung) ─────────────────────────────────────
async function doSaveCookies(label, cookies, isOverwrite) {
  const r = await new Promise(resolve =>
    chrome.runtime.sendMessage({
      action: 'saveCookies',
      label,
      origin: activeTab.origin,
      cookies
    }, resolve)
  );

  if (!r || !r.success) {
    swalError('Lỗi lưu local', r?.error || 'Không xác định');
    return;
  }

  const verb = isOverwrite ? 'Đã ghi đè!' : 'Đã lưu!';
  swalSuccess(verb, `"${label}" — ${cookies.length} cookies`);
  $('snap-name').value = '';
  loadSaved();

  // Upload lên Cloud
  chrome.runtime.sendMessage({
    action: 'autoUploadCloud',
    label,
    hostname: activeTab.hostname,
    origin: activeTab.origin,
    cookies
  });
}

$('btn-reload-saved').addEventListener('click', loadSaved);

// Toggle chỉ hiển thị web hiện tại
const currentSiteToggle = $('toggle-current-site');
if (currentSiteToggle) {
  currentSiteToggle.addEventListener('change', () => {
    onlyCurrentSite = currentSiteToggle.checked;
    chrome.storage.local.set({ onlyCurrentSite });
    loadSaved();   // reload danh sách
  });
}

// ── Actions ───────────────────────────────────────────────────────────────────
async function restoreSnap(s) {
  chrome.runtime.sendMessage({ action: 'restoreCookies', cookies: s.cookies }, async r => {
    if (r && r.success) {
      await swalSuccess('Khôi phục xong!', r.restored + ' cookies — đang tải lại trang...');
      chrome.tabs.reload(activeTab && activeTab.tabId ? activeTab.tabId : undefined, {}, () => {});
    } else {
      swalError('Lỗi khôi phục', r && r.error);
    }
  });
}

function copySnap(cookies) {
  const header = cookies.map(c => c.name + '=' + c.value).join('; ');
  navigator.clipboard.writeText(header)
    .then(() => swalSuccess('Đã copy!', cookies.length + ' cookies vào clipboard'))
    .catch(() => swalError('Không thể copy', 'Trình duyệt từ chối quyền clipboard'));
}

function exportSnap(s) {
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'cookies-' + s.label.replace(/\s+/g,'-') + '.json';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  swalSuccess('Xuất JSON', '"' + s.label + '" đã tải về máy');
}

async function deleteSnap(key) {
  const result = await swalConfirm('Xoá snapshot này?', 'Hành động này không thể hoàn tác.', '🗑 Xoá', 'warning');
  if (!result.isConfirmed) return;

  // ✅ Lấy thông tin snap TRƯỚC khi xoá
  const snapsRes = await new Promise(r => chrome.storage.local.get('snapshots', r));
  const snap = snapsRes.snapshots?.[key];

  // Xoá local
  chrome.runtime.sendMessage({ action: 'deleteSnapshot', key }, (res) => {
    if (!res || !res.success) {
      swalError('Lỗi xoá local', '');
      return;
    }

    // Gọi xoá trên Cloud — background tự đọc HARDCODED_API_URL hoặc cloudApiUrl từ storage
    if (snap) {
      const hostname = snap.origin?.replace(/^https?:\/\//, '').replace(/\/.*$/, '') || activeTab?.hostname || '';
      chrome.runtime.sendMessage({
        action: 'deleteFromCloud',
        web: hostname,
        name: snap.label
      });
    }

    swalSuccess('Đã xoá', '');
    loadSaved();
  });
}

// ── Import JSON ───────────────────────────────────────────────────────────────
$('btn-import-json').addEventListener('click', () => { $('json-file-input').click(); });
$('import-zone').addEventListener('click', () => $('json-file-input').click());
$('import-zone').addEventListener('dragover', e => { e.preventDefault(); $('import-zone').classList.add('drag-over'); });
$('import-zone').addEventListener('dragleave', () => $('import-zone').classList.remove('drag-over'));
$('import-zone').addEventListener('drop', e => {
  e.preventDefault();
  $('import-zone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) handleImportFile(file);
});
$('json-file-input').addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) handleImportFile(file);
  e.target.value = '';
});

async function handleImportFile(file) {
  if (!file.name.endsWith('.json') && file.type !== 'application/json') {
    swalError('File không hợp lệ', 'Chỉ hỗ trợ file .json'); return;
  }
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    await processImportedJSON(data, file.name);
  } catch(e) {
    swalError('Lỗi đọc file', 'File JSON không hợp lệ: ' + e.message);
  }
}

async function processImportedJSON(data, filename) {
  let snapshots = [];
  if (Array.isArray(data)) {
    if (data.length > 0 && data[0].name !== undefined && data[0].value !== undefined) {
      const origin = data[0].domain
        ? 'https://' + (data[0].domain.startsWith('.') ? data[0].domain.slice(1) : data[0].domain)
        : (activeTab ? activeTab.origin : 'https://unknown');
      const label = filename.replace('.json','') || 'Import';
      snapshots.push({ label, origin, cookies: data });
    } else {
      snapshots = data.filter(s => s.cookies && Array.isArray(s.cookies));
    }
  } else if (data.cookies && Array.isArray(data.cookies)) {
    snapshots.push(data);
  } else {
    swalError('Định dạng không hỗ trợ', 'File cần chứa cookies array hoặc snapshot hợp lệ'); return;
  }
  if (!snapshots.length) { swalError('Không có dữ liệu', 'Không tìm thấy cookie nào trong file'); return; }

  if (snapshots.length === 1) {
    const { value } = await Swal.fire({
      title: '📥 Import Cookie',
      html: '<div style="font-size:12px;margin-bottom:10px">Tìm thấy <strong>' + snapshots[0].cookies.length + '</strong> cookies từ <strong>' + (snapshots[0].origin || 'unknown') + '</strong></div>',
      input: 'text',
      inputLabel: 'Tên để lưu',
      inputValue: snapshots[0].label || filename.replace('.json',''),
      inputPlaceholder: 'Nhập tên...',
      showCancelButton: true,
      confirmButtonText: '📥 Import',
      cancelButtonText: 'Huỷ',
    });
    if (!value) return;
    snapshots[0].label = value.trim();
  }

  chrome.storage.local.get('snapshots', r => {
    const snaps = Object.assign({}, (r && r.snapshots) || {});
    let i = 0;
    const processNext = () => {
      if (i >= snapshots.length) {
        chrome.storage.local.set({ snapshots: snaps }, () => {
          swalSuccess('Import thành công!', 'Đã lưu ' + i + ' snapshot(s)');
          loadSaved();
          $('import-zone').style.display = 'none';
        });
        return;
      }
      const s = snapshots[i];
      const origin  = s.origin || (activeTab ? activeTab.origin : 'https://imported');
      const label   = s.label  || ('Import ' + (i + 1));
      const cookies = s.cookies || [];
      const key     = origin + '::' + label;
      snaps[key]    = { key, label, origin, cookies, count: cookies.length, savedAt: s.savedAt || new Date().toISOString(), imported: true };
      i++;
      processNext();
    };
    processNext();
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// TIMER MODAL
// ═══════════════════════════════════════════════════════════════════════════════
function openTimer(key, label, existingTimer) {
  timerKey        = key;
  $('t-name').value = label;
  $('t-note').value = existingTimer ? (existingTimer.note || '') : '';
  const defDate   = new Date((existingTimer ? existingTimer.deadlineMs : Date.now() + 3600000));
  const offset    = defDate.getTimezoneOffset() * 60000;
  $('t-dt').value = new Date(defDate - offset).toISOString().slice(0, 16);
  $('timer-overlay').classList.remove('hidden');
}

$('t-cancel').addEventListener('click', () => $('timer-overlay').classList.add('hidden'));
$('timer-overlay').addEventListener('click', e => { 
  if (e.target === $('timer-overlay')) $('timer-overlay').classList.add('hidden'); 
});

$('t-ok').addEventListener('click', async () => {
  const dtVal = $('t-dt').value;
  if (!dtVal) { 
    swalWarn('Thiếu thời gian', 'Chọn thời điểm hẹn giờ'); 
    return; 
  }

  const deadlineMs = new Date(dtVal).getTime();
  if (isNaN(deadlineMs)) { 
    swalWarn('Không hợp lệ', 'Thời gian không đúng'); 
    return; 
  }

  const note = $('t-note').value.trim();

  // Lưu timer vào local
  chrome.storage.local.get(['timers', 'snapshots'], async (res) => {
    const timers = (res && res.timers) || {};
    timers[timerKey] = { deadlineMs, note };
    await chrome.storage.local.set({ timers });

    $('timer-overlay').classList.add('hidden');
    loadSaved();

    // ====================== UPDATE TIMER LÊN PHP API ======================
    const snap = ((res && res.snapshots) || {})[timerKey];
    if (snap && cloudApiUrl) {
      try {
        const payload = {
          action: "save",
          web: snap.origin?.replace(/^https?:\/\//, '').replace(/\/.*$/, '') || activeTab?.hostname || '',
          name: snap.label,
          timerISO: new Date(deadlineMs).toISOString()
          // KHÔNG gửi cookie ở đây
        };

        console.log("⏰ Gửi update timer:", payload);

        const response = await fetch(cloudApiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const result = await response.json();
        console.log("⏰ Server response timer:", result);

        if (result.success) {
          console.log('✅ Đã cập nhật hẹn giờ lên Cloud');
        }
      } catch (e) {
        console.error('Lỗi update timer cloud:', e);
      }
    }

    const isPast = deadlineMs <= Date.now();
    if (isPast) showToast('warning', 'Thời điểm đã qua', 'Hẹn giờ đã lưu nhưng thời điểm đã qua');
    else showToast('success', 'Đã đặt hẹn giờ!');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// TAB: COOKIE HIỆN TẠI
// ═══════════════════════════════════════════════════════════════════════════════
function initLive() {
  loadLive();
}

function loadLive() {
  hide($('live-list'));
  hide($('live-empty'));
  show($('live-loading'));
  if (!activeTab) { hide($('live-loading')); show($('live-empty')); return; }

  chrome.runtime.sendMessage({ action: 'getCookiesForUrl', url: activeTab.url }, res => {
    hide($('live-loading'));
    if (!res || !res.success || !res.cookies.length) { show($('live-empty')); return; }
    liveCookies  = res.cookies;
    filteredLive = liveCookies.slice();
    renderLive();
    show($('live-list'));
  });
}

function renderLive() {
  const list = $('live-list');
  list.innerHTML = '';
  if (!filteredLive.length) {
    list.innerHTML = '<div class="empty"><div class="empty-ico">🔍</div><div class="empty-txt">Không tìm thấy.</div></div>';
    return;
  }
  filteredLive.forEach(c => {
    const isLong  = c.value.length > 80;
    const shortVal = isLong ? c.value.substring(0, 80) + '…' : c.value;

    const item = document.createElement('div');
    item.className = 'citem';

    const hdr = document.createElement('div');
    hdr.className = 'citem-hdr';

    const nameEl = document.createElement('div');
    nameEl.className = 'cname';
    nameEl.title     = c.name;
    nameEl.textContent = c.name;

    const domEl = document.createElement('span');
    domEl.className   = 'cdomain';
    domEl.textContent = c.domain;

    hdr.appendChild(nameEl);
    hdr.appendChild(domEl);

    const valEl = document.createElement('div');
    valEl.className   = 'cval';
    valEl.textContent = shortVal;
    if (isLong) {
      valEl.title = 'Nhấn để mở rộng';
      valEl.addEventListener('click', () => {
        const open = valEl.classList.toggle('open');
        valEl.textContent = open ? c.value : shortVal;
      });
    }

    const foot = document.createElement('div');
    foot.className = 'cfoot';

    const badges = document.createElement('div');
    badges.className = 'cbadges';
    if (c.secure)   mkBadge(badges, '🔒 Secure', 'rgba(86,212,154,.15)', 'var(--success)');
    if (c.httpOnly) mkBadge(badges, 'HTTP Only', 'rgba(245,197,66,.12)',  'var(--warn)');
    if (c.session)  mkBadge(badges, 'Session',   'rgba(124,127,147,.15)','var(--muted)');

    const actDiv = document.createElement('div');
    actDiv.style.cssText = 'display:flex;gap:5px;align-items:center';

    const copyBtn = btn('📋', 'btn btn-icon', () => {
      navigator.clipboard.writeText(c.name + '=' + c.value)
        .then(() => swalSuccess('Đã copy!', '"' + c.name + '" vào clipboard'))
        .catch(() => swalError('Không thể copy', ''));
    });
    copyBtn.title = 'Copy cookie';

    const delCookieBtn = document.createElement('button');
    delCookieBtn.className = 'btn-delete';
    delCookieBtn.innerHTML = '🗑 Xoá cookie';
    delCookieBtn.addEventListener('click', async () => {
      const result = await swalConfirm('Xoá cookie "' + c.name + '"?', 'Cookie sẽ bị xoá khỏi trình duyệt.', '🗑 Xoá', 'warning');
      if (!result.isConfirmed) return;
      chrome.runtime.sendMessage({ action: 'deleteCookie', cookieName: c.name, url: activeTab.url }, res => {
        if (res && res.success) { swalSuccess('Đã xoá!', '"' + c.name + '"'); loadLive(); }
        else swalError('Không thể xoá', '');
      });
    });

    actDiv.appendChild(copyBtn);
    actDiv.appendChild(delCookieBtn);
    foot.appendChild(badges);
    foot.appendChild(actDiv);

    item.appendChild(hdr);
    item.appendChild(valEl);
    item.appendChild(foot);
    list.appendChild(item);
  });
}

function mkBadge(parent, text, bg, color) {
  const b = document.createElement('span');
  b.className = 'badge';
  b.style.cssText = 'background:' + bg + ';color:' + color;
  b.textContent = text;
  parent.appendChild(b);
}

$('btn-logout').addEventListener('click', async () => {
  if (!activeTab) { swalError('Lỗi', 'Không xác định được trang hiện tại'); return; }
  chrome.runtime.sendMessage({ action: 'getCookiesForUrl', url: activeTab.url }, async res => {
    if (!res || !res.success || !res.cookies.length) { swalWarn('Không có cookie', 'Trang này chưa có cookie nào'); return; }
    const cookies = res.cookies;
    chrome.runtime.sendMessage({ action: 'logoutCookies', cookies }, async r => {
      if (r && r.success) {
        await swalSuccess('Đã đăng xuất!', 'Đặt hết hạn ' + r.expired + ' cookies — đang tải lại trang...');
        chrome.tabs.reload(activeTab.tabId || undefined, {}, () => {});
      } else {
        swalError('Lỗi đăng xuất', r && r.error);
      }
    });
  });
});

$('live-search').addEventListener('input', e => {
  const q    = e.target.value.toLowerCase().trim();
  filteredLive = q
    ? liveCookies.filter(c => c.name.toLowerCase().includes(q) || c.value.toLowerCase().includes(q) || c.domain.toLowerCase().includes(q))
    : liveCookies.slice();
  renderLive();
});

// ═══════════════════════════════════════════════════════════════════════════════
// TAB: CLOUD
// ═══════════════════════════════════════════════════════════════════════════════
let cloudApiUrl      = '';
let _sessionKey      = '';
let _isUrlHardcoded  = false;
let _isPassHardcoded = false;
let onlyCurrentSite = false;

// ── Khởi tạo config ngay khi popup load (không cần vào tab Cloud) ─────────────
function loadHardcodedConfig() {
	
// Load trạng thái toggle "Chỉ web hiện tại"
chrome.storage.local.get('onlyCurrentSite', r => {
  onlyCurrentSite = !!(r && r.onlyCurrentSite);
  const toggle = $('toggle-current-site');
  if (toggle) toggle.checked = onlyCurrentSite;
});

  chrome.runtime.sendMessage({ action: 'getHardcodedConfig' }, hc => {
    _isUrlHardcoded  = !!(hc && hc.apiUrl);
    _isPassHardcoded = !!(hc && hc.password);

    if (_isUrlHardcoded) {
      cloudApiUrl = hc.apiUrl;
    }
    if (_isPassHardcoded && !_sessionKey) {
      _sessionKey = hc.password;
    }

    // Nếu không có hardcoded URL → load từ storage
    if (!cloudApiUrl) {
      chrome.storage.local.get('cloudApiUrl', r => {
        if (r && r.cloudApiUrl) cloudApiUrl = r.cloudApiUrl;
      });
    }
    // Nếu không có hardcoded pass → load từ storage
    if (!_sessionKey) {
      chrome.storage.local.get('cloudAutoKey', r => {
        if (r && r.cloudAutoKey) _sessionKey = r.cloudAutoKey;
      });
    }
  });
}
// Gọi ngay khi popup khởi động
loadHardcodedConfig();

function encryptCookies(cookies, passphrase) {
  return CryptoJS.AES.encrypt(JSON.stringify(cookies), passphrase).toString();
}
function decryptCookies(ciphertext, passphrase) {
  const bytes = CryptoJS.AES.decrypt(ciphertext, passphrase);
  const plain = bytes.toString(CryptoJS.enc.Utf8);
  if (!plain) throw new Error('Sai mật khẩu hoặc dữ liệu bị hỏng');
  return JSON.parse(plain);
}
function keyFingerprint(p) {
  return CryptoJS.SHA256(p).toString().substring(0, 8).toUpperCase();
}

async function requireEncryptionKey(action = 'upload') {
  if (_sessionKey) return _sessionKey;
  const label = action === 'upload' ? '☁ Upload' : '⬇ Load';
  const { value } = await Swal.fire({
    title: '🔐 Nhập mật khẩu mã hoá',
    html: `<div style="font-size:12px;color:#888;margin-bottom:10px;line-height:1.6">
      Cookie sẽ được mã hoá bằng <strong>AES-256</strong> trước khi gửi lên Cloud.<br>
      Dùng <strong>cùng một mật khẩu</strong> khi Load về để giải mã.<br>
      <span style="color:#f5c542">⚠ Mất mật khẩu = mất cookie!</span></div>`,
    input: 'password',
    inputLabel: 'Mật khẩu mã hoá',
    inputPlaceholder: 'Nhập mật khẩu...',
    inputAttributes: { autocomplete: 'off', minlength: '4' },
    showCancelButton: true,
    confirmButtonText: label,
    cancelButtonText: 'Huỷ',
    inputValidator: v => { if (!v || v.length < 4) return 'Mật khẩu tối thiểu 4 ký tự'; }
  });
  if (!value) return null;
  _sessionKey = value;
  updateKeyStatusUI();
  return _sessionKey;
}

function clearSessionKey() {
  _sessionKey = '';
  updateKeyStatusUI();
  swalSuccess('Đã xoá mật khẩu session', 'Lần tới sẽ hỏi lại mật khẩu');
}

// ── Init Cloud ────────────────────────────────────────────────────────────────
async function initCloud() {
  // Dùng lại _isUrlHardcoded / _isPassHardcoded đã load từ loadHardcodedConfig()
  const urlInput   = $('cloud-api-url');
  const passInput  = $('cloud-auto-key');
  const btnSaveUrl = $('btn-save-api-url');
  const btnSaveKey = $('btn-save-auto-key');

  if (_isUrlHardcoded) {
    // URL cứng: hiển thị vào input và disable
    urlInput.value    = cloudApiUrl;
    urlInput.disabled = true;
    urlInput.title    = 'URL đã được HardSet trong background.js';
    if (btnSaveUrl) btnSaveUrl.style.display = 'none';
  } else {
    // Không cứng: cho phép nhập bình thường, hiển thị giá trị đã lưu nếu có
    urlInput.disabled = false;
    urlInput.title    = '';
    urlInput.value    = cloudApiUrl || '';
    if (btnSaveUrl) btnSaveUrl.style.display = '';
  }

  if (_isPassHardcoded) {
    // Pass cứng: disable input
    if (passInput) {
      passInput.disabled    = true;
      passInput.placeholder = '●●●●';
      passInput.title       = 'Mật khẩu đã được HardSet trong background.js';
    }
    if (btnSaveKey) btnSaveKey.style.display = 'none';
  } else {
    // Không cứng: cho phép nhập bình thường
    if (passInput) {
      passInput.disabled = false;
      passInput.title    = '';
    }
    if (btnSaveKey) btnSaveKey.style.display = '';
    // Kiểm tra xem đã lưu storage chưa để cập nhật placeholder
    chrome.storage.local.get('cloudAutoKey', r => {
      const hasStoredKey = !!(r && r.cloudAutoKey);
      if (passInput) {
        passInput.placeholder = hasStoredKey
          ? '●●●● (đã cài — nhập để đổi)'
          : 'Mật khẩu tự động upload khi lưu...';
      }
    });
  }

  updateKeyStatusUI();

  // Cập nhật status bar
  if (cloudApiUrl) {
    const fp      = _sessionKey ? ' · 🔑 ' + keyFingerprint(_sessionKey) : '';
    const autoTag = (_isPassHardcoded || _sessionKey) ? ' · 🤖 Auto' : '';
    setCloudStatus('idle', 'URL đã lưu — nhấn Load để tải danh sách' + fp + autoTag);
  } else {
    setCloudStatus('idle', 'Chưa cấu hình API URL');
  }
}

function setCloudStatus(type, text) {
  const el   = $('cloud-status');
  el.className = 'cloud-status ' + type;
  $('cloud-status-text').textContent = text;
  el.querySelector('span:first-child').textContent = { ok:'🟢', err:'🔴', idle:'⚪', loading:'🔄' }[type] || '⚪';
}

// ── Lưu API URL ───────────────────────────────────────────────────────────────
$('btn-save-api-url').addEventListener('click', () => {
  const url = $('cloud-api-url').value.trim();
  if (!url) { swalWarn('Chưa có URL', 'Nhập URL API'); return; }
  if (!url.startsWith('https://')) {
    swalWarn('URL không hợp lệ', 'URL phải bắt đầu bằng https://'); return;
  }
  cloudApiUrl = url;
  chrome.storage.local.set({ cloudApiUrl: url }, () => {
    swalSuccess('Đã lưu URL!', 'Nhấn "Kiểm tra kết nối" để xác nhận');
    setCloudStatus('idle', 'URL đã lưu — chưa kiểm tra kết nối');
  });
});

// ── Auto-upload key ───────────────────────────────────────────────────────────
$('btn-save-auto-key').addEventListener('click', () => {
  const val = $('cloud-auto-key').value.trim();
  chrome.storage.local.set({ cloudAutoKey: val || null }, () => {
    if (val) swalSuccess('Đã lưu mật khẩu auto-upload!', 'Background sẽ tự upload mỗi khi lưu snapshot');
    else swalSuccess('Đã xoá mật khẩu auto-upload', 'Background sẽ không tự upload nữa');
    $('cloud-auto-key').value = '';
  });
});

// ── Test kết nối ─────────────────────────────────────────────────────────────
$('btn-test-api').addEventListener('click', async () => {
  if (!cloudApiUrl) { 
    swalWarn('Chưa có URL', 'Nhập và lưu URL trước'); 
    return; 
  }

  setCloudStatus('loading', 'Đang kiểm tra...');

  try {
    const res = await cloudRequest('ping', null, 'GET');

    if (res.success && res.data && res.data.status === 'ok') {
      setCloudStatus('ok', 'Kết nối thành công — ' + (res.data.message || 'API sẵn sàng'));
      swalSuccess('Kết nối OK!', res.data.message || 'PHP API đang hoạt động');
    } else {
      setCloudStatus('err', 'API trả về lỗi: ' + (res.data?.error || 'unknown'));
      swalError('Kết nối thất bại', res.data?.error || 'Unknown error');
    }
  } catch (e) {
    setCloudStatus('err', 'Lỗi kết nối: ' + e.message);
    swalError('Lỗi kết nối', e.message);
  }
});

// ── Xoá session key ───────────────────────────────────────────────────────────
$('btn-clear-key').addEventListener('click', () => {
  if (!_sessionKey) { swalWarn('Chưa có key', 'Chưa nhập mật khẩu trong session này'); return; }
  clearSessionKey();
  setCloudStatus('idle', 'Đã xoá session key — sẽ hỏi lại lần tới');
});

// ── Load toàn bộ cookie từ Cloud ─────────────────────────────────────────────
$('btn-cloud-load').addEventListener('click', loadAllFromCloud);

async function loadAllFromCloud() {
  if (!cloudApiUrl) return swalWarn('Chưa có URL', 'Vui lòng cấu hình API URL ở tab Cloud');

  const loadEl = $('cloud-loading');
  show(loadEl);
  loadEl.innerHTML = SVG_SPINNER + '<span>Đang tải từ Cloud...</span>';

  try {
    // Lấy tất cả dữ liệu qua action=get (với key được mã hoá)
    const listRes = await cloudRequest('get', null, 'GET');

    if (!listRes.success || !listRes.data.success) {
      throw new Error(listRes.data?.error || 'Không lấy được dữ liệu từ Cloud');
    }

    const webs = listRes.data.data || [];
    let imported = 0;

    const snapsRes = await new Promise(r => chrome.storage.local.get('snapshots', r));
    let snaps = { ...(snapsRes.snapshots || {}) };

    for (const webItem of webs) {
      const hostname = webItem.web;
      const origin = `https://${hostname}`;

      for (const snapData of (webItem.snapshots || [])) {
        let cookies = snapData.cookies || snapData.cookie || [];

        // Giải mã AES nếu có session key
        if (_sessionKey && typeof cookies === 'string') {
          try {
            cookies = decryptCookies(cookies, _sessionKey);
          } catch (e) {
            console.warn('Giải mã thất bại:', hostname, snapData.name);
            continue; // bỏ qua snapshot không giải mã được
          }
        }

        const key = origin + '::' + (snapData.name || 'default');

        snaps[key] = {
          key,
          label: snapData.name,
          origin,
          cookies: Array.isArray(cookies) ? cookies : [],
          count: Array.isArray(cookies) ? cookies.length : 0,
          savedAt: snapData.savedAt || new Date().toISOString(),
          fromCloud: true
        };
        imported++;
      }
    }

    await chrome.storage.local.set({ snapshots: snaps });

    hide(loadEl);
    swalSuccess('✅ Import Cloud thành công!', `Đã import ${webs.length} Web · ${imported} cookie`);
    loadSaved();

  } catch (e) {
    hide(loadEl);
    swalError('Lỗi Load từ Cloud', e.message);
  }
}

function guessOrigin(sheetName) {
  const originMap = {
    facebook:'https://www.facebook.com',shopee:'https://shopee.vn',tiktok:'https://www.tiktok.com',
    google:'https://www.google.com',youtube:'https://www.youtube.com',twitter:'https://twitter.com',
    x:'https://x.com',claude:'https://claude.ai',chatgpt:'https://chatgpt.com',openai:'https://openai.com',
    github:'https://github.com',lazada:'https://www.lazada.vn',grab:'https://grab.com',
    zalo:'https://chat.zalo.me',linkedin:'https://www.linkedin.com',netflix:'https://www.netflix.com',
    spotify:'https://open.spotify.com',amazon:'https://www.amazon.com',discord:'https://discord.com',
  };
  const key = sheetName.toLowerCase().replace(/\s|\(cloud\)/g,'').replace(/_/g,'');
  return originMap[key] || ('https://' + sheetName.toLowerCase().replace(/\s+/g,'.') + '.com');
}


// ── Upload TẤT CẢ cookie đã lưu ──────────────────────────────────────────────
$('btn-upload-all').addEventListener('click', async () => {
  if (!cloudApiUrl) { swalWarn('Chưa có URL', 'Cấu hình API URL trước'); return; }

  // Lấy passphrase — ưu tiên sessionKey, fallback hỏi
  let passphrase = _sessionKey;
  if (!passphrase) {
    const stored = await new Promise(r => chrome.storage.local.get('cloudAutoKey', r));
    passphrase = stored.cloudAutoKey || null;
  }
  if (!passphrase) {
    passphrase = await requireEncryptionKey('upload');
    if (!passphrase) return;
  }

  // Đếm số snapshot
  const snapsRes = await new Promise(r => chrome.storage.local.get('snapshots', r));
  const total    = Object.keys(snapsRes.snapshots || {}).length;
  if (!total) { swalWarn('Không có dữ liệu', 'Chưa có snapshot nào để upload'); return; }

  const confirm = await swalConfirm(
    'Upload tất cả lên Cloud?',
    total + ' snapshot sẽ được mã hoá và upload lên Google Sheet.',
    '☁ Upload ' + total + ' snapshot',
    'question'
  );
  if (!confirm.isConfirmed) return;

  const loadEl = $('cloud-loading');
  loadEl.innerHTML = SVG_SPINNER + '<span>Đang upload ' + total + ' snapshot...</span>';
  show(loadEl);
  setCloudStatus('loading', 'Đang upload tất cả...');

  chrome.runtime.sendMessage({ action: 'uploadAllToCloud', passphrase }, async res => {
    hide(loadEl);
    if (res && res.success) {
      const msg = res.ok + '/' + res.total + ' thành công' + (res.fail ? ', ' + res.fail + ' lỗi' : '');
      setCloudStatus(res.fail ? 'err' : 'ok', msg);
      if (res.fail && res.errors && res.errors.length) {
        swalWarn('Upload hoàn tất (có lỗi)', msg + '\n\nLỗi:\n' + res.errors.slice(0,3).join('\n'));
      } else {
        await swalSuccess('Upload hoàn tất!', msg);
      }
    } else {
      setCloudStatus('err', '' + (res && res.error || 'Upload thất bại'));
      swalError('Lỗi upload', res && res.error);
    }
  });
});

function updateKeyStatusUI() {
  const el = $('key-status-text');
  if (!el) return;
  if (_sessionKey) {
    el.textContent = '🔑 Key đang dùng: ' + keyFingerprint(_sessionKey) + ' (fingerprint SHA256)';
    el.style.color = 'var(--success)';
  } else {
    el.textContent = 'Chưa nhập mật khẩu — sẽ hỏi khi Upload/Load';
    el.style.color = '';
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAB: BACKUP & RESTORE  (Cloud-first)
// ═══════════════════════════════════════════════════════════════════════════════
const BAK_MAGIC = 'CMBAK1'; // file signature

function initBackup() {
  refreshBackupStats();
  checkBackupCloudConfig();
}

// Kiểm tra & hiển thị thông báo nếu chưa có API URL / pass
function checkBackupCloudConfig() {
  const notice = $('bak-config-notice');
  if (!notice) return;
  if (!cloudApiUrl) {
    notice.style.display = '';
    $('bak-config-notice-text').textContent = '⚠ Chưa có API URL — vào tab ☁ Cloud để cài đặt';
  } else if (!_sessionKey) {
    notice.style.display = '';
    $('bak-config-notice-text').textContent = '⚠ Chưa có mật khẩu mã hoá — cấu hình ở tab ☁ Cloud';
  } else {
    notice.style.display = 'none';
  }
}

async function refreshBackupStats() {
  $('bstat-snaps').textContent   = '…';
  $('bstat-sites').textContent   = '…';
  $('bstat-cookies').textContent = '…';

  const res = await new Promise(r =>
    chrome.runtime.sendMessage({ action: 'getAllPersistentCookies' }, r)
  );
  if (!res || !res.success) { $('bstat-cookies').textContent = '!'; return; }

  const cookies = res.cookies;
  const sites   = new Set(cookies.map(c => c.domain.replace(/^\./, ''))).size;
  $('bstat-cookies').textContent = cookies.length;
  $('bstat-sites').textContent   = sites;

  const r2 = await new Promise(r => chrome.storage.local.get('snapshots', r));
  $('bstat-snaps').textContent   = Object.keys(r2.snapshots || {}).length;
}

// ── Danh sách domain Google bỏ qua khi backup ────────────────────────────────
const SKIP_DOMAINS = [
  // Google chính
  'google.com',
  'google.com.vn',

  // Dịch vụ / CDN / API
  'googleapis.com',
  'gstatic.com',
  'ggpht.com',
  'googleusercontent.com',
  'googlevideo.com',

  // Quảng cáo / Analytics
  'doubleclick.net',
  'googlesyndication.com',
  'googleadservices.com',
  'googletagmanager.com',
  'google-analytics.com',

  // YouTube
  'youtube.com',
  'youtu.be',
  'ytimg.com',

  // Blogger
  'blogger.com',
  'blogspot.com',

  // Firebase / GCP
  'appspot.com',
  'firebaseapp.com',
  'firebaseio.com',
  'withgoogle.com',

  // Android / Chrome / Chromium
  'android.com',
  'chrome.com',
  'chromium.org',

  // reCAPTCHA
  'recaptcha.net'
];

function isSkippedDomain(domain) {
  const d = domain.replace(/^\./, '').toLowerCase();

  const isSkipped = SKIP_DOMAINS.some(
    skip => d === skip || d.endsWith('.' + skip)
  );

  return isSkipped;
}

// ── BUILD EXPORT PAYLOAD ──────────────────────────────────────────────────────
async function buildBackupPayload(includeCloud) {
  const cookieRes = await new Promise(r =>
    chrome.runtime.sendMessage({ action: 'getAllPersistentCookies' }, r)
  );
  if (!cookieRes || !cookieRes.success) throw new Error(cookieRes?.error || 'Không lấy được cookie');

  // Lọc bỏ cookie Google/YouTube/Gmail/Drive...
  const allCookies  = cookieRes.cookies.filter(c => !isSkippedDomain(c.domain));
  const byDomain    = {};
  for (const c of allCookies) {
    const d = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
    if (!byDomain[d]) byDomain[d] = [];
    byDomain[d].push(c);
  }

  const snapRes  = await new Promise(r => chrome.storage.local.get(['snapshots', 'timers'], r));
  let snapshots  = Object.values(snapRes.snapshots || {});
  if (!includeCloud) snapshots = snapshots.filter(s => !s.fromCloud);

  return {
    magic:              BAK_MAGIC,
    version:            2,
    exportedAt:         new Date().toISOString(),
    encrypted:          false,
    browserCookies:     allCookies,
    browserCookieCount: allCookies.length,
    domainCount:        Object.keys(byDomain).length,
    snapshots,
    timers: snapRes.timers || {}
  };
}

// ── UPLOAD BACKUP LÊN CLOUD ───────────────────────────────────────────────────
$('btn-do-export').addEventListener('click', doExportToCloud);
async function doExportToCloud() {
  checkBackupCloudConfig();

  const prog = $('bak-export-progress');
  const bar  = $('bak-export-bar');
  prog.style.display = 'block';
  bar.style.width = '10%';

  // Lấy tên backup
  let label = $('bak-backup-name').value.trim();
  if (!label) {
    label = 'backup-' + new Date().toISOString().slice(0, 10);
    $('bak-backup-name').value = label;
  }

  // Yêu cầu mật khẩu nếu chưa có
  let passphrase = _sessionKey;
  if (!passphrase) {
    passphrase = await requireEncryptionKey('upload');
    if (!passphrase) { prog.style.display = 'none'; return; }
  }

  bar.style.width = '25%';

  const includeCloud = $('bak-include-cloud').checked;
  let payload;
  try {
    payload = await buildBackupPayload(includeCloud);
  } catch (e) {
    prog.style.display = 'none';
    swalError('Lỗi thu thập dữ liệu', e.message);
    return;
  }

  if (!payload.browserCookies.length) {
    prog.style.display = 'none';
    swalWarn('Không có cookie', 'Trình duyệt không có persistent cookie nào');
    return;
  }

  bar.style.width = '60%';

  chrome.runtime.sendMessage(
    { action: 'backupToCloud', label, payload, passphrase },
    res => {
      bar.style.width = '100%';
      setTimeout(() => { prog.style.display = 'none'; bar.style.width = '0%'; }, 1000);
      if (res && res.success) {
        showToast('success', `☁ Đã backup "${label}" lên Cloud!`,
          `${payload.browserCookieCount} cookies · ${payload.domainCount} trang`);
      } else {
        swalError('Backup thất bại', res && res.error);
      }
    }
  );
}

// ── XUẤT FILE .BAK (nút phụ) ─────────────────────────────────────────────────
$('btn-do-export-file').addEventListener('click', doExportFile);
async function doExportFile() {
  let passphrase = _sessionKey;
  if (!passphrase) {
    // hỏi mật khẩu
    const { value } = await Swal.fire({
      title: '🔐 Mật khẩu mã hoá file',
      html: '<div style="font-size:12px;color:#888;margin-bottom:8px">Để trống nếu không muốn mã hoá.</div>',
      input: 'password', inputPlaceholder: 'Mật khẩu (tuỳ chọn)...',
      showCancelButton: true, confirmButtonText: '⬇ Xuất', cancelButtonText: 'Huỷ'
    });
    if (value === undefined) return; // cancelled
    passphrase = value || null;
  }

  const includeCloud = $('bak-include-cloud').checked;
  let payload;
  try {
    payload = await buildBackupPayload(includeCloud);
  } catch (e) { swalError('Lỗi', e.message); return; }

  if (!payload.browserCookies.length) { swalWarn('Không có cookie', ''); return; }

  let fileContent;
  if (passphrase) {
    payload.encrypted = true;
    const cipher = CryptoJS.AES.encrypt(JSON.stringify(payload), passphrase).toString();
    fileContent = JSON.stringify({ magic: BAK_MAGIC, version: 2, encrypted: true, data: cipher });
  } else {
    fileContent = JSON.stringify(payload, null, 2);
  }

  const date  = new Date().toISOString().slice(0, 10);
  const fname = `cookie-backup-${date}.bak`;
  const blob  = new Blob([fileContent], { type: 'application/octet-stream' });
  const url   = URL.createObjectURL(blob);
  const a     = document.createElement('a');
  a.href = url; a.download = fname;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showToast('success', `Đã xuất ${payload.browserCookieCount} cookie!`, fname);
}

// ── LIỆT KÊ BACKUP TRÊN CLOUD ────────────────────────────────────────────────
$('btn-list-backups').addEventListener('click', loadCloudBackupList);

async function loadCloudBackupList() {
  if (!cloudApiUrl) {
    swalWarn('Chưa có URL', 'Cấu hình API ở tab ☁ Cloud');
    return;
  }

  const loadEl = $('bak-cloud-loading');
  const listEl = $('bak-cloud-list');
  show(loadEl);
  listEl.innerHTML = '';

  try {
    const res = await cloudRequest('backup_list', null, 'GET');

    hide(loadEl);

    if (!res.success || !res.data.success) {
      swalError('Lỗi tải danh sách', res.data?.error);
      return;
    }

    const backups = res.data.backups || [];
    if (!backups.length) {
      listEl.innerHTML = '<div class="empty"><div class="empty-ico">📦</div><div class="empty-txt">Chưa có backup nào trên Cloud.</div></div>';
      return;
    }

    // Phần render danh sách giữ nguyên như cũ...
    backups.forEach(b => {
      const displayName = b.filename || b.name || 'Không tên';
      const displayDate = b.created_at || '';
      const displaySize = b.size_kb ? b.size_kb + ' KB' : '';

      const item = document.createElement('div');
      item.className = 'bak-cloud-item';
      item.innerHTML = `
        <div class="bak-cloud-ico">📦</div>
        <div class="bak-cloud-info">
          <div class="bak-cloud-name">${esc(displayName)}</div>
          <div class="bak-cloud-meta">
            ${displayDate ? '🕒 ' + new Date(displayDate).toLocaleString('vi-VN') : ''}
            ${displaySize ? ' · 💾 ' + displaySize : ''}
          </div>
        </div>
        <div class="bak-cloud-actions"></div>`;

      const acts = item.querySelector('.bak-cloud-actions');
      const restBtn = btn('↩ Restore', 'btn btn-primary btn-xs', () => doRestoreFromCloud(b.filename));
      const delBtn  = btn('🗑', 'btn btn-danger btn-xs', () => doDeleteCloudBackup(b.filename, item));

      acts.appendChild(restBtn);
      acts.appendChild(delBtn);
      listEl.appendChild(item);
    });

  } catch (e) {
    hide(loadEl);
    swalError('Lỗi', e.message);
  }
}


// ── RESTORE TỪ CLOUD ─────────────────────────────────────────────────────────
async function doRestoreFromCloud(label) {
  checkBackupCloudConfig();

  let passphrase = _sessionKey;
  if (!passphrase) {
    passphrase = await requireEncryptionKey('load');
    if (!passphrase) return;
  }

  const loadEl = $('bak-cloud-loading');
  show(loadEl);

  chrome.runtime.sendMessage({ action: 'restoreFromCloud', label, passphrase }, async res => {
    hide(loadEl);
    if (!res || !res.success) {
      swalError('Khôi phục thất bại', res && res.error);
      return;
    }
    await applyBackupPayload(res.payload, res.savedAt);
  });
}

// ── XOÁ BACKUP TRÊN CLOUD ───────────────────────────────────────────────────
async function doDeleteCloudBackup(filename, itemElement) {
  if (!filename) return swalError('Lỗi', 'Không tìm thấy tên file backup');

  const confirm = await swalConfirm(
    '🗑 Xoá backup này?',
    `Bạn có chắc muốn xoá backup "${filename}" trên Cloud?\n\nHành động này không thể hoàn tác.`,
    '🗑 Xoá vĩnh viễn',
    'warning'
  );

  if (!confirm.isConfirmed) return;

  try {
    const res = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        action: 'deleteFromCloud',
        web: filename,           // Dùng filename làm key
        name: filename
      }, resolve);
    });

    if (res && res.success) {
      showToast('success', 'Đã xoá backup', filename);
      if (itemElement) itemElement.remove();   // Xóa item khỏi UI
    } else {
      swalError('Xoá thất bại', res?.error || 'Lỗi không xác định');
    }
  } catch (e) {
    swalError('Lỗi', e.message);
  }
}

// ── RESTORE TỪ FILE ───────────────────────────────────────────────────────────
$('btn-restore-file').addEventListener('click', () => $('backup-restore-file').click());
$('backup-restore-file').addEventListener('change', e => {
  const f = e.target.files[0];
  if (f) doImportBackup(f);
  e.target.value = '';
});

async function doImportBackup(file) {
  const prog = $('bak-import-progress');
  const bar  = $('bak-import-bar');
  prog.style.display = 'block';
  bar.style.width = '10%';

  let raw;
  try { raw = await file.text(); }
  catch(e) { prog.style.display = 'none'; swalError('Không đọc được file', e.message); return; }

  let parsed;
  try { parsed = JSON.parse(raw); }
  catch(e) { prog.style.display = 'none'; swalError('File không hợp lệ', 'Không phải JSON'); return; }

  if (parsed.magic !== BAK_MAGIC) {
    prog.style.display = 'none';
    swalError('Sai định dạng', 'File này không phải backup từ Cookie Manager');
    return;
  }

  bar.style.width = '30%';
  let payload = parsed;

  if (parsed.encrypted) {
    let pw = '';
    // Thử dùng _sessionKey trước
    if (_sessionKey) {
      try {
        const bytes = CryptoJS.AES.decrypt(parsed.data, _sessionKey);
        const plain = bytes.toString(CryptoJS.enc.Utf8);
        if (plain) { payload = JSON.parse(plain); pw = _sessionKey; }
      } catch {}
    }
    if (!pw) {
      prog.style.display = 'none';
      const { value } = await Swal.fire({
        title: '🔐 Nhập mật khẩu',
        html: '<div style="font-size:12px;color:#888;margin-bottom:8px">File được mã hoá AES-256.</div>',
        input: 'password', inputPlaceholder: 'Mật khẩu giải mã...',
        showCancelButton: true, confirmButtonText: '🔓 Giải mã', cancelButtonText: 'Huỷ'
      });
      if (!value) return;
      prog.style.display = 'block'; bar.style.width = '30%';
      try {
        const bytes = CryptoJS.AES.decrypt(parsed.data, value);
        const plain = bytes.toString(CryptoJS.enc.Utf8);
        if (!plain) throw new Error('empty');
        payload = JSON.parse(plain);
      } catch {
        prog.style.display = 'none';
        swalError('Sai mật khẩu', 'Không thể giải mã');
        return;
      }
    }
  }

  bar.style.width = '60%';
  await applyBackupPayload(payload, payload.exportedAt);
  bar.style.width = '100%';
  setTimeout(() => { prog.style.display = 'none'; bar.style.width = '0%'; }, 1000);
}

// ── CUSTOM RESTORE CONFIRM MODAL ─────────────────────────────────────────────
function showRestoreConfirmModal({ savedAt, hasBrowserCookies, cookieCount, domainCount, hasSnapshots, snapCount }) {
  return new Promise(resolve => {
    // Inject styles nếu chưa có
    if (!document.getElementById('rcm-style')) {
      const st = document.createElement('style');
      st.id = 'rcm-style';
      st.textContent = `
        @keyframes rcmFadeIn  { from{opacity:0} to{opacity:1} }
        @keyframes rcmSlideUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        #rcm-overlay { animation: rcmFadeIn .18s ease; }
        #rcm-modal   { animation: rcmSlideUp .2s ease; }
        .rcm-row { display:flex; align-items:center; gap:10px; padding:8px 12px; border-radius:8px; font-size:12px; }
        .rcm-row-date  { background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); }
        .rcm-row-cook  { background:rgba(86,212,154,.07);  border:1px solid rgba(86,212,154,.2);  color:#56d49a; }
        .rcm-row-snap  { background:rgba(91,156,246,.07);  border:1px solid rgba(91,156,246,.2);  color:#5b9cf6; }
        .rcm-row-warn  { background:rgba(245,197,66,.08);  border:1px solid rgba(245,197,66,.25); color:#f5c542; margin-top:4px; }
        .rcm-row .rcm-ico  { font-size:16px; flex-shrink:0; }
        .rcm-row .rcm-lbl  { flex:1; line-height:1.5; }
        .rcm-row .rcm-val  { font-weight:700; font-size:13px; }
        .rcm-actions { display:flex; gap:8px; margin-top:16px; }
        .rcm-btn { flex:1; padding:9px 12px; border:none; border-radius:9px; font-size:12px; font-weight:700; cursor:pointer; transition:all .14s; display:flex; align-items:center; justify-content:center; gap:6px; }
        .rcm-btn:hover { transform:translateY(-1px); filter:brightness(1.08); }
        .rcm-btn:active { transform:translateY(0); filter:brightness(.96); }
        .rcm-btn-cancel  { background:rgba(255,255,255,.07); color:#9ca3af; border:1px solid rgba(255,255,255,.1); }
        .rcm-btn-confirm { background:linear-gradient(135deg,#d97757,#c9623f); color:#fff; box-shadow:0 3px 10px rgba(217,119,87,.35); }
      `;
      document.head.appendChild(st);
    }

    const overlay = document.createElement('div');
    overlay.id = 'rcm-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center';

    const modal = document.createElement('div');
    modal.id = 'rcm-modal';
    modal.style.cssText = 'background:#1a1d27;border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:20px;width:310px;max-width:96vw;box-shadow:0 12px 40px rgba(0,0,0,.6)';

    const dateStr = new Date(savedAt || 0).toLocaleString('vi-VN');

    modal.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
        <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#d97757,#c9623f);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;box-shadow:0 3px 10px rgba(217,119,87,.3)">↩</div>
        <div>
          <div style="font-size:14px;font-weight:700;color:#e8e9f0">Xác nhận khôi phục</div>
          <div style="font-size:11px;color:#6b7280;margin-top:2px">Dữ liệu sẽ được ghi vào trình duyệt</div>
        </div>
      </div>
      <div style="height:1px;background:rgba(255,255,255,.07);margin-bottom:12px"></div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <div class="rcm-row rcm-row-date">
          <span class="rcm-ico">📅</span>
          <span class="rcm-lbl" style="color:#9ca3af">Backup ngày</span>
          <span class="rcm-val" style="color:#e8e9f0;font-size:11px">${dateStr}</span>
        </div>
        ${hasBrowserCookies ? `
        <div class="rcm-row rcm-row-cook">
          <span class="rcm-ico">🍪</span>
          <span class="rcm-lbl">Cookie trình duyệt</span>
          <span class="rcm-val">${cookieCount} cookies<span style="font-weight:400;font-size:11px;color:#9ca3af"> / ${domainCount} trang</span></span>
        </div>` : ''}
        ${hasSnapshots ? `
        <div class="rcm-row rcm-row-snap">
          <span class="rcm-ico">📦</span>
          <span class="rcm-lbl">Snapshots extension</span>
          <span class="rcm-val">${snapCount} snapshots</span>
        </div>` : ''}
        <div class="rcm-row rcm-row-warn">
          <span class="rcm-ico">⚠</span>
          <span class="rcm-lbl" style="font-size:11px">Cookie sẽ được ghi thẳng vào trình duyệt. Không thể hoàn tác.</span>
        </div>
      </div>
      <div class="rcm-actions">
        <button class="rcm-btn rcm-btn-cancel" id="rcm-cancel">✕ Huỷ</button>
        <button class="rcm-btn rcm-btn-confirm" id="rcm-ok">⬇ Khôi phục ngay</button>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    const close = (val) => { overlay.remove(); resolve(val); };
    modal.querySelector('#rcm-cancel').addEventListener('click', () => close(false));
    modal.querySelector('#rcm-ok').addEventListener('click', () => close(true));
    overlay.addEventListener('click', e => { if (e.target === overlay) close(false); });
  });
}

// ── ÁP DỤNG PAYLOAD (dùng chung cho Cloud & File) ────────────────────────────
async function applyBackupPayload(payload, savedAt) {
  const { snapshots: newSnaps = [], timers: newTimers = {}, browserCookies = [], domainCount = 0 } = payload;
  const hasBrowserCookies = browserCookies.length > 0;
  const hasSnapshots      = newSnaps.length > 0;

  if (!hasBrowserCookies && !hasSnapshots) {
    swalWarn('Payload trống', 'Không có cookie nào trong backup này');
    return;
  }

  const confirmed = await showRestoreConfirmModal({
    savedAt,
    hasBrowserCookies,
    cookieCount: browserCookies.length,
    domainCount,
    hasSnapshots,
    snapCount: newSnaps.length
  });
  if (!confirmed) return;

  // 1. Khôi phục cookie trình duyệt
  let restoredCookies = 0, failedCookies = 0;
  if (hasBrowserCookies) {
    const r2 = await new Promise(r =>
      chrome.runtime.sendMessage({ action: 'restoreCookies', cookies: browserCookies }, r)
    );
    restoredCookies = r2?.restored || 0;
    failedCookies   = r2?.failed   || 0;
  }

  // 2. Merge snapshots vào storage
  let addedSnaps = 0, overwrittenSnaps = 0;
  if (hasSnapshots) {
    const existRes = await new Promise(r => chrome.storage.local.get('snapshots', r));
    const merged   = Object.assign({}, existRes.snapshots || {});
    for (const s of newSnaps) {
      const key = s.key || (s.origin + '::' + s.label);
      if (merged[key]) overwrittenSnaps++; else addedSnaps++;
      merged[key] = { ...s, key, restoredAt: new Date().toISOString() };
    }
    const timerRes    = await new Promise(r => chrome.storage.local.get('timers', r));
    const mergedTimers = Object.assign({}, timerRes.timers || {}, newTimers);
    await chrome.storage.local.set({ snapshots: merged, timers: mergedTimers });
  }

  refreshBackupStats();

  let msg = '';
  if (hasBrowserCookies) msg += `🍪 ${restoredCookies} cookie khôi phục (${failedCookies} lỗi)`;
  if (hasSnapshots)      msg += (msg ? ' · ' : '') + `📦 ${addedSnaps} snap mới, ${overwrittenSnaps} ghi đè`;
  showToast('success', 'Khôi phục thành công!', msg);

  if (hasSnapshots) {
    setTimeout(() => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      const savedTab = document.querySelector('.tab[data-tab="saved"]');
      if (savedTab) savedTab.classList.add('active');
      $('panel-saved').classList.add('active');
      loadSaved();
    }, 1500);
  }
}